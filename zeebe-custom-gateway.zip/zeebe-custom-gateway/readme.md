# Custom Gateway (CGW)
This microservice's main task is to expose the brokers gRPC endpoint while authorizing every call towards the broker.
The secondary task of this microservice is authenticating the clients until the OAuth implementation is available.

## Authentication (connecting to the gateway)
In order to be able to connect to the gateway the client must provide its credentials in the Authorization header.
Currently the only supported authentication method is Basic authentication. The java based worker can us the latest 
version of the zeebe-worker-base to enable basic authentication.

Authentication data must be provided as a base64 value of userId:password in the metadata of ALL grpc calls with the key
**"Authorization"**. If the requested entry is not in the header the CGW will terminate the call immediately with grpc
error code **INVALID_ARGUMENT**. If the entry is given, but the credentials are not valid the CGW will terminate the call 
immediately with grpc error code **UNAUTHENTICATED**.  

## Authorization and RBAC

Authorization is done on an APM level. A client must have sufficient rights to

## Accessing mysql tables
Light database-mapping software library, **JOOQ** is added to custom gateway which can generate Java code from your database and lets you build type safe SQL queries through its fluent API.

HikariCP is a light weight JDBC connection pool as DbHandler which is responsible for connecting to mysql and accessing the tables.
**Example usage:**

    try {
        DSLContext create = DSL.using(MysqlHandler.getConn(), SQLDialect.MYSQL);
        Result<Record> result = create.select().from(Tables.WORKERMANAGEMENT).fetch();
    } catch (SQLException e) {
        e.printStackTrace();
    }

In case of db schema change or **regeneration** required use to following method:
 * Use code below to regenerate DAO sources
 * The best way to access mysql is to portforward the pod to your localhost
 * For include or exclude other tables edit the **jooq-config.xml** accordingly in resources.

**HINT:**

    ******  kubectl -n zb port-forward mysql-0 3306:3306  ******

    try {
        GenerationTool.generate(
            Files.readString(
                Path.of("C:\\dev\\zb-platform\\zeebe-custom-gateway\\src\\main\\resources\\jooq-config.xml")
                )
            );
    } catch (Exception e) {
        e.printStackTrace();
    }

## Provided services
The Custom Gateway currently provides three services:
 * ZeebeBrokerGatewayService
 * ClientManagementService
 * RoleManagementService
 
 Authentication is required on all three services. Authorization is done on all three services.
 
 ### ZeebeBrokerGatewayService
 This service provides all the gRPC endpoints provided by the ZeebeBroker.
 Authorization is done based on APM level on all RPCs except Topology. 
 
 ### ClientManagementService
 tbd.
 
 ### RoleManagementService
 tbd.
 
 ## Other info

 ### Health check REST endpoints
 
  * **/health/is-running (GET)**:
  Returns true if the service is running.  
  Sample output: true
  * **/health/version(GET)**:
  Returns the version of the service based on the version in the pom.xml  
  Sample output: 2.6.0
  * **/health/status(GET)**:
  Returns the status of the service in JSON format containing:
    * **"isHealthy"** : boolean field describing the service is healthy or not
    * **"brokerStatus"** : Short string description of the state of the connection towards the broker. 
    * **"extractorStatus"** : Short string description of the state of the connection towards the RocksDBExtractor.  
    
    Sample output:  
    ```json
    { 
      "brokerStatus" : "Broker is available.",
      "extractorStatus" : "RocksDBExtractor is not available due to DEADLINE EXCEED.",
      "isHealthy" : false
    }
    ```
 
 ### Active workers report functionality
  tbd.
 
 ### Properties
  tbd.
 
 ## Contributing
 
 This project is a maven based java project using grpc. In order to be able to compile the code you will have to 
 generate all the grpc code from the proto files in the proto package (the last proto is imported as a dependency.). 
 Code generation is done by protoc which is provided as a maven dependency, and the compile goal triggers it.  
 
 ## Changelog

**4.4.1**  
Improvements:
   * linked JIRA task: SCO-1347
   * made responses in error scenarios less confusing for clients, plus added indication for whitelisting as an option
   
   * linked JIRA task: SCO-1628
   * made various responses in error scenarios less confusing for clients
   * added transactionId to responses in error scenarios
   
   * increased ActivateJob's deadline in ZeebeBrokerClient from 15 sec to 120 sec
 
**4.4.0**  
Improvements:
   * linked JIRA task: SCO-1347
   * Call Activity authorization feature turned on
   * Implemented whitelisting for call activity authorization
   * added whitelist based on impacted workflows deployed to NP and P

**4.3.3**  
Workaround:
   * linked JIRA task: SCO-1568
   * TEMPORARY WORKAROUND: turned off authorization in cases where RDBE can't find jobKey in the DB on endpoints 
     completeJob and failJob. Authentication still needed and is intact.

**4.3.2**  
Improvements:
   * linked JIRA task: SCO-1568
   * fixed issue where getting this error message: "Corresponding BpmnProcessId does not contain apm."
     in cases where RDBE responded NOT_FOUND or other issue.
   * reverted most changes done in 4.3.1

**4.3.1**
   * some emergency log changes for debugging, most of them reverted in 4.3.2

**4.3.0**  
Improvements:
   * linked JIRA task: SCO-1347
   * Call Activities are now authorized:
      * each and every call activity has to call a process that is in the same apm as the workflow 
      (apm part of bpmnProcesId of both the target and the source workflow matches)
   * for legacy workflow support this feature can be turned off by setting the auth.isCallActivityHardening property to false 
   * logging verbosity changed back to info in most of ZeebeBrokerService transaction related logs

**4.2.0**  
Improvements:
   * linked JIRA task: SCO-1101
   * Added partitioning support
   * auto detecting topology:
      * auto detecting the extractors
      * auto detecting partition count
   * fixed healthcheck to work with multiple extractors
   * added caching on rocksdb extractor related endpoints:
      * cache is in hazelcast with a given TTL for each entry (specified in properties)
   * Updated Zeebe dependencies' version from 0.26.3 to 0.26.4

**4.1.1**  
Improvements:
   * Updated Zeebe dependencies' version from 0.26.0 to 0.26.3

**4.1.0**  
Improvements:
   * linked JIRA task: tbd
   * Adding JOOQ framework to access mysql db
   * Adding Generated DAO sources for accessing **WorkerOwnership, ApmManagement, WorkerManagement** tables
   * Adding jooq-config.xml to resources and example code to main class in case of db schema change and regeneration required
   * Adding HikariCP a light weight JDBC connection pool as DbHandler so it will be responsible connecting to mysql and accessing the tables

**4.0.0**
Improvements:
   * linked JIRA task: SCO-931
   * Fully asynchronous communication on the gateway service implemented:
      * every incoming call now gets stored with their response observer and a separate thread executes them and waits for the answer
      * the activateJobs endpoint is an exception to this. It's also async but since it is streaming it does not need to be stored.
 
**3.2.0**  
Improvements:
   * linked JIRA task: SCO-732
   * Added verification step for messages when deploying a workflow. Same restrictions are in place for messages as for jobs:
     * message name must follow convention <apm>.<message name>
     * user must have write access right on the given apm
     * apm must be the same as the whole workflows (the one in the bpmn process id)
   * linked JIRA task: SCO-1090
   * Updated zb dependencies' version from 0.24.5 to 0.26.0

**3.1.2**  
Improvements:
   * linked JIRA task: SCO-1030
   * Fixed hazelcast address
 
**3.1.1**  
Improvements:
   * linked JIRA task: SCO-1034
   * Improved logging errors where in some cases in ZeebeBrokerService error class name was logged instead of the actual error message.

Bugfix:  
   * Fixed hazelcast address since the member on localhost is no longer available. (now connecting to hazelcast-0) 
 
**3.1.0**  
Improvements:
   * Updated Zeebe dependencies' version from 0.24.3 to 0.24.5
 
**3.0.0**  
Bugfix:
   * linked JIRA task: SCO-647
   * Fix APM extract bug from Message Name (PublishMessage function)

**2.10.1**  
Improvements:  
   * linked JIRA task: MI-1988
   * Added hazelcast availability to health check report.
   * Changed log level of all StatusRuntimeExceptions from debug to error in ZeebeBrokerService.
   * Log4j2 log level is now loaded from env var ZEEBE_LOG_LEVEL if available, otherwise defaults to info.

**2.10.0**  
New features:  
  * linked JIRA task: MI-1947
  * Added support for FEEL expressions in taskTypes of a workflow if and only if the given taskType starts with ="\<APM\>. . 
  
Improvements:  
  * linked JIRA task: MI-1741
  * Now the cgw won't crash if the hazelcast cluster is not available. 
    Instead, it will try to reconnect on every new request towards hazelcast BUT AT MOST ONCE A MINUTE. 
 
**2.9.0**
  * linked JIRA task: MI-1741
  * using zeebe version 0.24.3
  * Improved logging in all grpc endpoints got moved from INFO level to DEBUG some more frequent logs were moved to TRACE
  * Added active workers report functionality
  * Added hazelcast client
 
**2.8.0**  
  * linked JIRA task: MI-1915
  * using zeebe version 0.23.2
  * Improved logging in all grpc endpoints, a grpc endpoint will now always log three lines:
    * One when it is called
    * One when it is authorized with the outcome of the authorization
    * One when it succeeds / fails. And the reasons in fail scenario.
  * All logs in every grpc service will now contain the id of the client who called the endpoint plus another id that binds the log to the accessed resource. 
    If it is connected to multiple resources (for example workflow bulk deployment) a transaction id is generated to be able to identify each log. 
  * Improved exception handling to simplify the code.
 
**2.7.0**
  * linked JIRA task: MI-1768
  * Added getRoles rpc to RoleManagementService
  * Introduced **breaking proto change, shifted all status enum values up by one and added an UNDEFINED option as value 0.
  
**2.6.0**
  * linked JIRA task: MI-1726
  * Added health check REST endpoints
 
**2.5.0**
  * linked JIRA task: MI-1615
  * From now on workers can only take jobs with the jobType matching the workers clientId.
  
**2.4.0**
  * Authorization done for all JobType based RPCs using the new endpoint in RocksDBExtractor.
  * required RDBE version: 1.7.0
  * required worker-base version: 2.1.3
  
**2.3.0** :
  * added support for new broker RPCs CreateWorkflowInstanceWithResult and ThrowError 