
#!/bin/bash
set -x

# Detect if running in an ADO release pipeline or not
if [[ ! -z $SYSTEM_ARTIFACTSDIRECTORY  ]];then cd $SYSTEM_ARTIFACTSDIRECTORY/caas-setup/caas-setup;fi

kubectl -n zb-core-services delete  deployment.apps/rocksdb-extractor

kubectl -n zb-core-services apply -f rocksdb-extractor-deploy.yaml
kubectl -n zb-core-services apply -f rocksdb-extractor-service.yaml
