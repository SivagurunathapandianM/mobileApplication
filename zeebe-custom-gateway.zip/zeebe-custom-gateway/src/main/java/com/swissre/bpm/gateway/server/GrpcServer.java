package com.swissre.bpm.gateway.server;

import com.swissre.bpm.gateway.client.HazelcastImdgClient;
import com.swissre.bpm.gateway.client.RocksDbExtractorClient;
import com.swissre.bpm.gateway.client.ZeebeBrokerClient;
import com.swissre.bpm.gateway.server.auth.AuthorizationHelper;
import com.swissre.bpm.gateway.server.service.ClientManagementService;
import com.swissre.bpm.gateway.server.service.RoleManagementService;
import com.swissre.bpm.gateway.server.service.ZeebeBrokerService;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

public class GrpcServer {
    private static final Logger LOG = LogManager.getLogger(GrpcServer.class);

    private Properties appProps;
    private int port;
    private Server server;

    public GrpcServer(Properties appProps) {
        this.appProps = appProps;
        this.port = Integer.parseInt(appProps.getProperty("grpcServer.port"));
    }

    public void start(HazelcastImdgClient hazelcastImdgClient, RocksDbExtractorClient rocksDbExtractorClient) throws IOException {

        ZeebeBrokerClient zeebeBrokerClient;
        AuthorizationHelper authorizationHelper = new AuthorizationHelper(appProps,rocksDbExtractorClient);

        if(Boolean.parseBoolean(appProps.getProperty("brokerClient.usePlainText"))){
            LOG.info("Starting Broker using plain text.");
            zeebeBrokerClient = new ZeebeBrokerClient(
                    appProps.getProperty("brokerClient.brokerHost"),
                    Integer.parseInt(appProps.getProperty("brokerClient.brokerPort")),
                    Integer.parseInt(appProps.getProperty("brokerClient.deadlineSec")),
                    Integer.parseInt(appProps.getProperty("brokerClient.clientExecutor.threadPoolSize")));
        } else {
            LOG.info("Starting Broker NOT using plain text.");
            zeebeBrokerClient = new ZeebeBrokerClient(
                    appProps.getProperty("brokerClient.brokerHost"),
                    Integer.parseInt(appProps.getProperty("brokerClient.brokerPort")),
                    new File(appProps.getProperty("brokerClient.certChainPath")),
                    new File(appProps.getProperty("brokerClient.privateKeyPath")),
                    Integer.parseInt(appProps.getProperty("brokerClient.deadlineSec")),
                    Integer.parseInt(appProps.getProperty("brokerClient.clientExecutor.threadPoolSize")));
        }

        if(Boolean.parseBoolean(appProps.getProperty("grpcServer.usePlainText"))){
            server = ServerBuilder.forPort(port)
                .intercept(new MetadataProcessor(hazelcastImdgClient))
                    .addService(new ZeebeBrokerService(
                            zeebeBrokerClient,
                            authorizationHelper,
                            hazelcastImdgClient,
                            appProps))
                    .addService(new ClientManagementService(authorizationHelper,appProps))
                    .addService(new RoleManagementService(authorizationHelper))
                    .build()
                    .start();
        } else {
            server = ServerBuilder.forPort(port)
                .intercept(new MetadataProcessor(hazelcastImdgClient))
                    .useTransportSecurity(new File(appProps.getProperty("grpcServer.certChainPath")),
                            new File(appProps.getProperty("grpcServer.privateKeyPath")))
                    .addService(new ZeebeBrokerService(
                            zeebeBrokerClient,
                            authorizationHelper,
                            hazelcastImdgClient,
                            appProps))
                    .addService(new ClientManagementService(authorizationHelper,appProps))
                    .addService(new RoleManagementService(authorizationHelper))
                    .build()
                    .start();
        }


        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                LOG.error("Shutting down grpc server gracefully since JVM is shutting down.");
                GrpcServer.this.stop();
                LOG.error("grpc server shutdown finished.");
            }
        });
    }

    private void stop(){
        server.shutdown();
    }

    public void blockUntilShutdown() throws InterruptedException {
        server.awaitTermination();
    }
}
