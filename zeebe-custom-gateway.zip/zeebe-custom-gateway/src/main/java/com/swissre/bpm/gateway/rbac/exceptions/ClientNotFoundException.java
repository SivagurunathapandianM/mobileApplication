package com.swissre.bpm.gateway.rbac.exceptions;

public class ClientNotFoundException extends ClientCredentialsException {
    public ClientNotFoundException(String message) {
        super(message);
    }
}
