package com.swissre.bpm.gateway.client;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.swissre.bpm.gateway.caching.ZeebeElementStore;
import com.swissre.bpm.gateway.client.util.HazelcastException;
import com.swissre.bpm.gateway.server.util.exceptions.UnavailableAuthException;
import com.swissre.bpm.grpc.rocksdbextractor.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.concurrent.*;

public class RocksDbExtractorClient {

    private static final Logger LOG = LogManager.getLogger(com.swissre.bpm.gateway.client.RocksDbExtractorClient.class);
    private final Map<Integer, RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderExtractorStubs = new ConcurrentHashMap<>();
    private ExecutorService executorService;
    private final int rocksDbExtractorPort;
    private final int grpcDeadlineSec;
    private final ZeebeBrokerClient zeebeBrokerClient;
    private final ZeebeElementStore zeebeElementStore;

    public RocksDbExtractorClient(Properties properties, ZeebeElementStore zeebeElementStore) throws StatusRuntimeException{
        LOG.info("Started RocksDbExtractorClient towards address: {}:{}", properties.getProperty("rocksDbExtractor.host"),Integer.parseInt(properties.getProperty("rocksDbExtractor.port")));
        this.grpcDeadlineSec = Integer.parseInt(properties.getProperty("rocksDbExtractor.deadlineSec"));
        this.rocksDbExtractorPort = Integer.parseInt(properties.getProperty("rocksDbExtractor.port"));
        this.executorService = Executors.newFixedThreadPool(Integer.parseInt(properties.getProperty("rocksDbExtractor.clientExecutor.threadPoolSize")));
        this.zeebeBrokerClient = new ZeebeBrokerClient(
                properties.getProperty("brokerClient.brokerHost"),
                Integer.parseInt(properties.getProperty("brokerClient.brokerPort")),
                Integer.parseInt(properties.getProperty("brokerClient.deadlineSec")),
                1);
        this.zeebeElementStore = zeebeElementStore;
        selectLeaderBrokers();
    }

    public BpmnProcessIdMessage extractBpmnProcessIdForWorkflowInstanceId(WorkflowInstanceIdMessage request) throws StatusRuntimeException, UnavailableAuthException {
        LOG.debug("extractBpmnProcessIdForWorkflowInstanceId got called. grpcDeadlineSec: {}, request: {}",grpcDeadlineSec,request);

        try {
            String bpmnProcessId = zeebeElementStore.getBpmnProcessIdForWorkflowInstanceId(request.getWorkflowInstanceId());
            LOG.trace("Cache hit for workflowInstanceId {} bpmnProcessId was {}",request.getWorkflowInstanceId(),bpmnProcessId);
            return BpmnProcessIdMessage
                    .newBuilder()
                    .setStatusCode(StatusCode.CACHED)
                    .setBpmnProcessId(bpmnProcessId)
                    .build();
        } catch (HazelcastException e) {
            LOG.trace("Cache miss for workflowInstanceId {}",request.getWorkflowInstanceId());
        }

        Map<Integer, ListenableFuture<BpmnProcessIdMessage>> listenableResponses = new HashMap<>();

        for(Map.Entry<Integer, RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderExtractorStub : leaderExtractorStubs.entrySet()){
            
            ListenableFuture<BpmnProcessIdMessage> listenableResponse = leaderExtractorStub.getValue()
                    .withDeadlineAfter(grpcDeadlineSec, TimeUnit.SECONDS)
                    .extractBpmnProcessIdForWorkflowInstanceId(request);
            
            listenableResponses.put(leaderExtractorStub.getKey(),listenableResponse);
        }
        
        BpmnProcessIdMessage response = null;
        try {
            response = evaluateFutureCalls(listenableResponses);
        } catch (UnavailableAuthException ignored) {}

        if(response != null && response.getStatusCode().equals(StatusCode.SUCCESS)) {
            zeebeElementStore.putBpmnProcessIdForWorkflowInstanceId(request.getWorkflowInstanceId(),response.getBpmnProcessId());
            return response;
        } else {

            synchronized (leaderExtractorStubs) {
                selectLeaderBrokers();
            }

            listenableResponses.clear();

            for (Map.Entry<Integer, RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderExtractorStub : leaderExtractorStubs.entrySet()) {

                ListenableFuture<BpmnProcessIdMessage> listenableResponse = leaderExtractorStub.getValue()
                        .withDeadlineAfter(grpcDeadlineSec, TimeUnit.SECONDS)
                        .extractBpmnProcessIdForWorkflowInstanceId(request);

                listenableResponses.put(leaderExtractorStub.getKey(), listenableResponse);
            }

            response = evaluateFutureCalls(listenableResponses);

            if(response.getStatusCode().equals(StatusCode.SUCCESS)) {
                zeebeElementStore.putBpmnProcessIdForWorkflowInstanceId(request.getWorkflowInstanceId(), response.getBpmnProcessId());
            }

            return response;
        }

    }

    public BpmnProcessIdMessage extractBpmnProcessIdForWorkflowKey(WorkflowKeyMessage request) throws StatusRuntimeException, UnavailableAuthException {
        LOG.debug("extractBpmnProcessIdForWorkflowKey got called. grpcDeadlineSec: {}, request: {}", grpcDeadlineSec,request);

        try {
            String bpmnProcessId = zeebeElementStore.getBpmnProcessIdForWorkflowKey(request.getWorkflowKey());
            LOG.trace("Cache hit for workflowKey {} bpmnProcessId was {}",request.getWorkflowKey(),bpmnProcessId);
            return BpmnProcessIdMessage
                    .newBuilder()
                    .setStatusCode(StatusCode.CACHED)
                    .setBpmnProcessId(bpmnProcessId)
                    .build();
        } catch (HazelcastException e) {
            LOG.trace("Cache miss for workflowKey {}",request.getWorkflowKey());
        }

        Map<Integer, ListenableFuture<BpmnProcessIdMessage>> listenableResponses = new HashMap<>();

        for(Map.Entry<Integer, RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderExtractorStub : leaderExtractorStubs.entrySet()){

            ListenableFuture<BpmnProcessIdMessage> listenableResponse = leaderExtractorStub.getValue()
                    .withDeadlineAfter(grpcDeadlineSec, TimeUnit.SECONDS)
                    .extractBpmnProcessIdForWorkflowKey(request);

            listenableResponses.put(leaderExtractorStub.getKey(),listenableResponse);
        }

        BpmnProcessIdMessage response = null;
        try {
            response = evaluateFutureCalls(listenableResponses);
        } catch (UnavailableAuthException ignored) {}

        if(response != null && response.getStatusCode().equals(StatusCode.SUCCESS)) {
            zeebeElementStore.putBpmnProcessIdForWorkflowKey(request.getWorkflowKey(),response.getBpmnProcessId());
            return response;
        } else {

            synchronized (leaderExtractorStubs) {
                selectLeaderBrokers();
            }

            listenableResponses.clear();

            for (Map.Entry<Integer, RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderExtractorStub : leaderExtractorStubs.entrySet()) {

                ListenableFuture<BpmnProcessIdMessage> listenableResponse = leaderExtractorStub.getValue()
                        .withDeadlineAfter(grpcDeadlineSec, TimeUnit.SECONDS)
                        .extractBpmnProcessIdForWorkflowKey(request);

                listenableResponses.put(leaderExtractorStub.getKey(), listenableResponse);
            }

            response = evaluateFutureCalls(listenableResponses);

            if( response.getStatusCode().equals(StatusCode.SUCCESS)) {
                zeebeElementStore.putBpmnProcessIdForWorkflowKey(request.getWorkflowKey(), response.getBpmnProcessId());
            }
        }

        return response;
    }

    public BpmnProcessIdMessage extractBpmnProcessIdForJobKey(JobKeyMessage request) throws StatusRuntimeException, UnavailableAuthException {
        LOG.debug("extractBpmnProcessIdForWorkflowInstanceId got called. grpcDeadlineSec: {}, request: {}", grpcDeadlineSec,request);

        try {
            String bpmnProcessId = zeebeElementStore.getBpmnProcessIdForJobKey(request.getJobKey());
            LOG.trace("Cache hit for jobKey {} bpmnProcessId was {}",request.getJobKey(),bpmnProcessId);
            return BpmnProcessIdMessage
                    .newBuilder()
                    .setStatusCode(StatusCode.CACHED)
                    .setBpmnProcessId(bpmnProcessId)
                    .build();
        } catch (HazelcastException e) {
            LOG.trace("Cache miss for jobKey {}",request.getJobKey());
        }

        Map<Integer, ListenableFuture<BpmnProcessIdMessage>> listenableResponses = new HashMap<>();

        for(Map.Entry<Integer, RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderExtractorStub : leaderExtractorStubs.entrySet()){

            ListenableFuture<BpmnProcessIdMessage> listenableResponse = leaderExtractorStub.getValue()
                    .withDeadlineAfter(grpcDeadlineSec, TimeUnit.SECONDS)
                    .extractBpmnProcessIdForJobKey(request);

            listenableResponses.put(leaderExtractorStub.getKey(),listenableResponse);
        }

        BpmnProcessIdMessage response = null;
        try {
            response = evaluateFutureCalls(listenableResponses);
        } catch (UnavailableAuthException ignored) {}

        if (response != null && response.getStatusCode().equals(StatusCode.SUCCESS)) {
            zeebeElementStore.putBpmnProcessIdForJobKey(request.getJobKey(),response.getBpmnProcessId());
            return response;
        } else {
            synchronized (leaderExtractorStubs) {
                selectLeaderBrokers();
            }

            listenableResponses.clear();

            for(Map.Entry<Integer, RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderExtractorStub : leaderExtractorStubs.entrySet()){

                ListenableFuture<BpmnProcessIdMessage> listenableResponse = leaderExtractorStub.getValue()
                        .withDeadlineAfter(grpcDeadlineSec, TimeUnit.SECONDS)
                        .extractBpmnProcessIdForJobKey(request);

                listenableResponses.put(leaderExtractorStub.getKey(),listenableResponse);
            }

            response = evaluateFutureCalls(listenableResponses);

            if(response.getStatusCode().equals(StatusCode.SUCCESS)) {
                zeebeElementStore.putBpmnProcessIdForJobKey(request.getJobKey(),response.getBpmnProcessId());
            }

            return response;
        }
    }

    private BpmnProcessIdMessage evaluateFutureCalls(Map<Integer, ListenableFuture<BpmnProcessIdMessage>> listenableFutureResponses) throws UnavailableAuthException {

        BpmnProcessIdMessage response = null;

        for(Map.Entry<Integer, ListenableFuture<BpmnProcessIdMessage>> listenableFutureEntry: listenableFutureResponses.entrySet()){
            try {
                response = listenableFutureEntry.getValue().get(grpcDeadlineSec+1,TimeUnit.SECONDS);
                if(response.getStatusCode().equals(StatusCode.SUCCESS)) {
                   return response;
                }
            } catch (InterruptedException | ExecutionException | TimeoutException | StatusRuntimeException e) {
                LOG.error("Unable to reach RocksDBExtractor", e);
                throw new UnavailableAuthException(e.getMessage());
            }
        }

        return response;
    }

    private void selectLeaderBrokers() throws StatusRuntimeException{
        synchronized (leaderExtractorStubs) {
            leaderExtractorStubs.clear();
            GatewayOuterClass.TopologyResponse topologyResponse = zeebeBrokerClient
                    .topologyBlocking(GatewayOuterClass.TopologyRequest.newBuilder().build());

            Map<Integer, String> leaderPartitionHosts = new HashMap<>();
            List<GatewayOuterClass.BrokerInfo> brokers = topologyResponse.getBrokersList();
            LOG.debug("Found broker, got topology: {}", topologyResponse);
            for (GatewayOuterClass.BrokerInfo brokerIterator : brokers) {
                for (GatewayOuterClass.Partition partitionIterator : brokerIterator.getPartitionsList()) {
                    LOG.debug("Broker {} has {} role on partition {}", brokerIterator.getHost(), partitionIterator.getRole(), partitionIterator.getPartitionId());
                    if (partitionIterator.getRole().equals(GatewayOuterClass.Partition.PartitionBrokerRole.LEADER)) {
                        if(!leaderPartitionHosts.containsValue(brokerIterator.getHost())) {
                            LOG.debug("Partition's (partitionId: {}) leader was found on node (nodeId: {}) on host: {}",
                                    partitionIterator.getPartitionId(), brokerIterator.getNodeId(), brokerIterator.getHost());

                            leaderPartitionHosts.put(partitionIterator.getPartitionId(), brokerIterator.getHost());
                        } else {
                            LOG.debug("Partition's (partitionId: {}) leader was found on node (nodeId: {}) on host: {} but is not used because there is already an entry for that host.",
                                    partitionIterator.getPartitionId(), brokerIterator.getNodeId(), brokerIterator.getHost());
                        }
                    }

                }
            }

            for (Map.Entry<Integer, String> leaderPartitionHost : leaderPartitionHosts.entrySet()) {
                ManagedChannel channel = ManagedChannelBuilder
                        .forAddress(
                                leaderPartitionHost.getValue(),
                                rocksDbExtractorPort
                        )
                        .usePlaintext()
                        .build();
                leaderExtractorStubs.put(leaderPartitionHost.getKey(), RocksDBExtractorServiceGrpc.newFutureStub(channel));
                LOG.info("New leaderExtractorStub created towards: {}:{}", leaderPartitionHost.getValue(), rocksDbExtractorPort);
            }

        }
    }

    public JsonObject getStatus() {
        JsonObject output = new JsonObject();
        JsonArray outputArray = new JsonArray();
        boolean isAllHealthy = true;
        for(Map.Entry<Integer,RocksDBExtractorServiceGrpc.RocksDBExtractorServiceFutureStub> leaderStub : leaderExtractorStubs.entrySet()) {
            JsonObject leaderState = new JsonObject();
            boolean isHealthy = false;
            String extractorConnectionStatus = "";

            try {

                BpmnProcessIdMessage bpmnProcessIdMessage = leaderStub.getValue().extractBpmnProcessIdForWorkflowInstanceId(WorkflowInstanceIdMessage.newBuilder().setWorkflowInstanceId(1).build()).get();
                if (bpmnProcessIdMessage != null) {
                    extractorConnectionStatus = "RocksDBExtractor is available.";
                    isHealthy = true;
                } else {
                    extractorConnectionStatus = "RocksDBExtractor is not available.";
                }

            } catch (io.grpc.StatusRuntimeException ex) {
                extractorConnectionStatus = "RocksDBExtractor is not available, got gRPC exception: " + ex.getStatus().getCode();
            } catch (ExecutionException ex) {
                if(ex.getCause() instanceof io.grpc.StatusRuntimeException) {
                    extractorConnectionStatus = "RocksDBExtractor is not available got gRPC exception: " + ((io.grpc.StatusRuntimeException)ex.getCause()).getStatus().getCode();
                } else {
                    extractorConnectionStatus = "RocksDBExtractor is not available due to other error.";
                }
            } catch (Exception ex) {
                extractorConnectionStatus = "RocksDBExtractor is not available due to other error.";
            } finally {
                isAllHealthy = isAllHealthy && isHealthy;
            }

            leaderState.addProperty("partition",leaderStub.getKey().toString());
            leaderState.addProperty("status",extractorConnectionStatus);
            leaderState.addProperty("isHealthy",isHealthy);
            outputArray.add(leaderState);
        }
        output.add("partition client statuses",outputArray);
        output.addProperty("isHealthy",isAllHealthy);
        return output;
    }
}
