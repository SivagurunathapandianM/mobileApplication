package com.swissre.bpm.gateway.server.auth;

import com.swissre.bpm.gateway.rbac.ClientHandler;
import com.swissre.bpm.gateway.rbac.exceptions.ClientNotFoundException;
import com.swissre.bpm.gateway.client.RocksDbExtractorClient;
import com.swissre.bpm.gateway.rbac.model.RoleComparator;
import com.swissre.bpm.gateway.server.util.exceptions.*;
import com.swissre.bpm.grpc.customgateway.Role;
import com.swissre.bpm.grpc.rocksdbextractor.BpmnProcessIdMessage;
import com.swissre.bpm.grpc.rocksdbextractor.JobKeyMessage;
import com.swissre.bpm.grpc.rocksdbextractor.WorkflowInstanceIdMessage;
import com.swissre.bpm.grpc.rocksdbextractor.WorkflowKeyMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Properties;

public class AuthorizationHelper {
    private static final Logger LOG = LogManager.getLogger(AuthorizationHelper.class);
    private Properties appProps;
    private final RocksDbExtractorClient rocksDbExtractorClient;

    public AuthorizationHelper(Properties appProps, RocksDbExtractorClient rocksDbExtractorClient) {
        this.appProps = appProps;
        this.rocksDbExtractorClient = rocksDbExtractorClient;
    }

    /*
    This is a problematic one since elementInstanceKey is not a concrete thing.
    ElementInstanceKey is a key of an element, the problem is that an element can be multiple things.
    An element can be a workflow or a workflow instance, or a message etc.
    This function will try to authenticate
        - as the elementInstanceKey was a workflowKey, and if it fails it will retry
        - as the elementInstanceKey way a workflowInstanceId

    Later we can add more options.
    * */
    public boolean authorizeBasedOnElementInstanceKey(String clientId, Role requiredRole, long elementInstanceKey) throws NotFoundException, UnknownAuthException, MalformedRequestContentException, UnavailableAuthException {
        LOG.trace("Authorizing based on ElementInstanceKey: {} for clientId: {}",elementInstanceKey,clientId);

        try {
            LOG.trace("Authorizing based on ElementInstanceKey as if it was a workflowKey");
            return authorizeBasedOnWorkflowKey(clientId,requiredRole,elementInstanceKey);
        } catch (NotFoundException | AuthException e) {
            LOG.trace("Authorizing based on ElementInstanceKey as if it was a workflowInstanceId");
            return authorizeBasedOnWorkflowInstanceId(clientId,requiredRole, elementInstanceKey);
        }
    }

    public boolean authorizeBasedOnMessageName(String clientId, Role requiredRole, String messageName) throws MalformedRequestContentException {
        LOG.trace("Authorizing based on MessageName: {} for clientId: {}",messageName,clientId);
        String apm;

        try {
            apm = extractApmFromEntity(messageName);
            LOG.trace("Successfully got apm: {} for messageName: {}",apm,messageName);
        } catch (MalformedRequestContentException e) {
            throw new MalformedRequestContentException("The given messageName (" + messageName + ") does not contain apm.");
        }

        try {
            return authorizeOnline(clientId, requiredRole, apm);
        } catch (AuthorizationUnavailableException a) {
            return authorizeOffline(clientId, requiredRole, apm);
        }
    }

    public boolean authorizeBasedOnBpmnProcessId(String clientId, Role requiredRole, String bpmnProcessId) throws MalformedRequestContentException {
        LOG.trace("Authorizing based on BpmnProcessId: {} for clientId: {}",bpmnProcessId,clientId);
        String apm;

        try {
            apm = extractApmFromEntity(bpmnProcessId);
            LOG.trace("Successfully got apm: {} for bpmnProcessId: {}",apm,bpmnProcessId);
        } catch (MalformedRequestContentException e) {
            throw new MalformedRequestContentException("The given bpmnProcessId (" + bpmnProcessId + ") does not contain apm.");
        }

        try {
            return authorizeOnline(clientId, requiredRole, apm);
        } catch (AuthorizationUnavailableException a) {
            return authorizeOffline(clientId, requiredRole, apm);
        }
    }

    public boolean authorizeBasedOnJobType(String clientId, Role requiredRole, String jobType) throws MalformedRequestContentException {
        LOG.trace("Authorizing based on jobType: {} for clientId: {}",jobType,clientId);
        String apm;

        try {
            apm = extractApmFromEntity(jobType);
            LOG.trace("Successfully got apm: {} for jobType: {}",apm,jobType);
        } catch (MalformedRequestContentException e) {
            throw new MalformedRequestContentException("The given jobType (" + jobType + ") does not contain apm.");
        }

        try {
            return authorizeOnline(clientId, requiredRole, apm);
        } catch (AuthorizationUnavailableException a) {
            return authorizeOffline(clientId, requiredRole, apm);
        }
    }

    public boolean authorizeBasedOnWorkflowKey(String clientId, Role requiredRole, Long workflowKey) throws NotFoundException, MalformedRequestContentException, UnknownAuthException, UnavailableAuthException {
        LOG.trace("Authorizing based on WorkFlowKey: {} for clientId: {}",workflowKey,clientId);

        WorkflowKeyMessage requestTowardsExtractor = WorkflowKeyMessage.newBuilder()
                .setWorkflowKey(workflowKey)
                .build();

        BpmnProcessIdMessage responseFromExtractor = rocksDbExtractorClient.extractBpmnProcessIdForWorkflowKey(requestTowardsExtractor);

        switch (responseFromExtractor.getStatusCode()) {
            case SUCCESS:
            case CACHED:
                LOG.trace("Authorizing based on WorkFlowKey, got bpmnProcessId: {} for workflowKey: {}",responseFromExtractor.getBpmnProcessId(),workflowKey);
                String apm;

                try {
                    apm = extractApmFromEntity(responseFromExtractor.getBpmnProcessId());
                } catch (MalformedRequestContentException e) {
                    throw new MalformedRequestContentException("Corresponding BpmnProcessId (" + responseFromExtractor.getBpmnProcessId() + ") does not contain apm.");
                }

                try {
                    return authorizeOnline(clientId, requiredRole, apm);
                } catch (AuthorizationUnavailableException a) {
                    return authorizeOffline(clientId, requiredRole, apm);
                }
            case NOT_FOUND:
                LOG.trace("Can't find workflowKey: {}.",workflowKey);
                throw new NotFoundException("Did not find workflowKey in RocksDb");
            default:
                LOG.trace("Can't find apm for workflowKey: {} Unknown error happened.",workflowKey);
                throw new UnknownAuthException("Unknown error happened while checking RocksDb.");
        }
    }

    public boolean authorizeBasedOnJobKey(String clientId, Role requiredRole, long jobKey) throws NotFoundException, MalformedRequestContentException, UnknownAuthException, UnavailableAuthException {
        LOG.trace("Authorizing based on JobKey: {} for clientId: {}",jobKey,clientId);

        JobKeyMessage requestTowardsExtractor = JobKeyMessage.newBuilder()
                .setJobKey(jobKey)
                .build();

        BpmnProcessIdMessage responseFromExtractor = rocksDbExtractorClient.extractBpmnProcessIdForJobKey(requestTowardsExtractor);

        switch (responseFromExtractor.getStatusCode()) {
            case SUCCESS:
            case CACHED:
                LOG.trace("Authorizing based on JobKey, got bpmnProcessId: {} for JobKey: {}",responseFromExtractor.getBpmnProcessId(),jobKey);
                String apm;
                try {
                    apm = extractApmFromEntity(responseFromExtractor.getBpmnProcessId());
                } catch (MalformedRequestContentException e) {
                    throw new MalformedRequestContentException("Corresponding BpmnProcessId (" + responseFromExtractor.getBpmnProcessId() + ") does not contain apm.");
                }

                try {
                    return authorizeOnline(clientId, requiredRole, apm);
                } catch (AuthorizationUnavailableException a) {
                    return authorizeOffline(clientId, requiredRole, apm);
                }
            case NOT_FOUND:
                LOG.trace("Can't find JobKey: {}.",jobKey);
                throw new NotFoundException("Did not find JobKey in RocksDb.");
            default:
                LOG.trace("Can't find apm for jobKey: {} Unknown error happened.",jobKey);
                throw new UnknownAuthException("Unknown error happened while checking RocksDb.");
        }
    }

    public boolean authorizeBasedOnWorkflowInstanceId(String clientId, Role requiredRole, long workflowInstanceId) throws NotFoundException, MalformedRequestContentException, UnknownAuthException, UnavailableAuthException {
        LOG.trace("Authorizing based on WorkFlowInstanceId: {} for clientId: {}",workflowInstanceId,clientId);

        WorkflowInstanceIdMessage requestTowardsExtractor = WorkflowInstanceIdMessage.newBuilder()
                .setWorkflowInstanceId(workflowInstanceId)
                .build();

        BpmnProcessIdMessage responseFromExtractor = rocksDbExtractorClient.extractBpmnProcessIdForWorkflowInstanceId(requestTowardsExtractor);

        switch (responseFromExtractor.getStatusCode()) {
            case SUCCESS:
            case CACHED:
                LOG.trace("Authorizing based on WorkFlowInstanceId, got bpmnProcessId: {} for workflowInstanceId: {}",responseFromExtractor.getBpmnProcessId(),workflowInstanceId);
                String apm;

                try {
                    apm = extractApmFromEntity(responseFromExtractor.getBpmnProcessId());
                } catch (MalformedRequestContentException e) {
                    throw new MalformedRequestContentException("Corresponding BpmnProcessId (" + responseFromExtractor.getBpmnProcessId() + ") does not contain apm.");
                }

                try {
                    return authorizeOnline(clientId, requiredRole, apm);
                } catch (AuthorizationUnavailableException a) {
                    return authorizeOffline(clientId, requiredRole, apm);
                }
            case NOT_FOUND:
                LOG.trace("Can't find workflowInstanceId: {}.",workflowInstanceId);
                throw new NotFoundException("Did not find bpmnProcessId in RocksDb");
            default:
                LOG.trace("Can't find apm for workflowInstanceId: {} Unknown error happened.",workflowInstanceId);
                throw new UnknownAuthException("Unknown error happened while checking RocksDb.");
        }
    }

    public boolean authorizeBasedOnApm(String clientId, Role requiredRole, String apm) {
        try {
            return authorizeOnline(clientId, requiredRole, apm);
        } catch (AuthorizationUnavailableException a) {
            return authorizeOffline(clientId, requiredRole, apm);
        }
    }

    private boolean authorizeOnline(String clientId, Role requiredRole,  String apm) throws AuthorizationUnavailableException {
        clientId = clientId.toUpperCase();
        apm = apm.toUpperCase();
        //TODO implement when rbac server is available
        throw new AuthorizationUnavailableException("Online rbac unimplemented.");
    }

    private boolean authorizeOffline(String clientId, Role requiredRole, String apm) {
        clientId = clientId.toUpperCase();
        apm = apm.toUpperCase();

        Role actualRole = null;
        try {
            actualRole = ClientHandler.getInstance().getRoleForClientForApm(clientId,apm);
        } catch (ClientNotFoundException e) {
            return false;
        }
        RoleComparator roleComparator = new RoleComparator();
        return roleComparator.compare(actualRole, requiredRole) >= 0;
    }

    private String extractApmFromEntity(String entity) throws MalformedRequestContentException {
        if(entity.contains(".")) {
            return entity.split("\\.")[0];
        } else {
            throw new MalformedRequestContentException();
        }
    }

}
