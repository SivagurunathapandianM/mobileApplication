package com.swissre.bpm.gateway.rbac.exceptions;

public class ClientAlreadyExistsException extends ClientCredentialsException {
    public ClientAlreadyExistsException(String message) {
        super(message);
    }
}
