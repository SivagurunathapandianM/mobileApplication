package com.swissre.bpm.gateway.rbac.model;

public class UnsafeClientCredentials {
    private String clientId;
    private String plainTextPassword;

    private UnsafeClientCredentials(){}

    public UnsafeClientCredentials(String clientId, String plainTextPassword) {
        this.clientId = clientId;
        this.plainTextPassword = plainTextPassword;
    }

    public String getClientId() {
        return clientId;
    }

    public String getPlainTextPassword() {
        return plainTextPassword;
    }
}