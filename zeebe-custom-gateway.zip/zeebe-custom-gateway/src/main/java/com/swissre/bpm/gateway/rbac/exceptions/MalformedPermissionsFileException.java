package com.swissre.bpm.gateway.rbac.exceptions;

public class MalformedPermissionsFileException extends Exception{
    public MalformedPermissionsFileException() {
    }

    public MalformedPermissionsFileException(String message) {
        super(message);
    }
}
