package com.swissre.bpm.gateway.rbac;

import com.swissre.bpm.gateway.rbac.exceptions.*;
import com.swissre.bpm.gateway.rbac.model.Client;
import com.swissre.bpm.grpc.customgateway.Role;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ClientHandler implements CredentialHandler, PermissionHandler {

    private static ClientHandler INSTANCE;

    private final Logger LOG = LogManager.getLogger(ClientHandler.class);

    private final ConcurrentHashMap<String, Client> clientMap = new ConcurrentHashMap<>();

    private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
    private final Lock readLock = rwLock.readLock();
    private final Lock writeLock = rwLock.writeLock();
    private String separator = ";;";
    private String permissionsFileLocation;
    private String credentialsFileLocation;

    private ClientHandler(){}

    public synchronized static ClientHandler getInstance(){
        if(INSTANCE == null){
            INSTANCE = new ClientHandler();
        }
        return INSTANCE;
    }

    public void init(Properties appPropertiesIn) throws ResourceNotFoundException, IOException, MalformedCredentialsFileException, MalformedPermissionsFileException, FileManipulationException {
        credentialsFileLocation = appPropertiesIn.getProperty("files.credentialsFileLocation");
        permissionsFileLocation = appPropertiesIn.getProperty("files.permissionsFileLocation");
        separator = appPropertiesIn.getProperty("files.separator");
        if(credentialsFileLocation == null){
            throw new ResourceNotFoundException("Can not find credentials file at " + appPropertiesIn.getProperty("files.credentialsFileLocation"));
        }
        clientMap.clear();
        populateClientsMap();
    }

    private Client getClientForId(String key) throws ClientNotFoundException {
        readLock.lock();
        try {
            Client ret = clientMap.get(key);
            if (ret != null) {
                return ret;
            } else {
                throw new ClientNotFoundException("No client exists with the given credentials.");
            }
        } finally {
            readLock.unlock();
        }
    }

    @Override
    public String getPasswordHashForClient(String clientId) throws ClientNotFoundException {
        clientId = clientId.toUpperCase();
        readLock.lock();
        try {
            return getClientForId(clientId).getHashedPassword();
        } finally {
            readLock.unlock();
        }
    }

    @Override
    public void addClientCredentials(String clientId, String passwordHash) throws IOException, FileManipulationException, ClientAlreadyExistsException {
        clientId = clientId.toUpperCase();
        if(!clientMap.containsKey(clientId)) {
            writeLock.lock();
            try {
                clientMap.put(clientId, new Client(clientId, passwordHash));
                updateClientCredentialsFile();
            } catch (FileManipulationException | IOException e) {
                clientMap.remove(clientId);
                throw e;
            } finally {
                writeLock.unlock();
            }
        } else {
            throw new ClientAlreadyExistsException("A client with this id already exists.");
        }
    }

    @Override
    public void removeClientCredentials(String clientId) throws IOException, FileManipulationException, ClientNotFoundException {
        clientId = clientId.toUpperCase();
        Client clientBackup = getClientForId(clientId);
        writeLock.lock();
        try {
            clientMap.remove(clientId);
            updateClientCredentialsFile();
            updatePermissionsFile();
        } catch (FileManipulationException | IOException e) {
            clientMap.put(clientId,clientBackup);
            throw e;
        } finally {
            writeLock.unlock();
        }
    }

    @Override
    public void modifyClientCredentials(String clientId, String passwordHash) throws IOException, FileManipulationException, ClientNotFoundException {
        clientId = clientId.toUpperCase();
        String originalHash = getClientForId(clientId).getHashedPassword();
        writeLock.lock();
        try {
            getClientForId(clientId).setHashedPassword(passwordHash);
            updateClientCredentialsFile();
        } catch (FileManipulationException | IOException e) {
            getClientForId(clientId).setHashedPassword(originalHash);
            throw e;
        } finally {
            writeLock.unlock();
        }
    }

    @Override
    public void addRoleForClientForApm(String clientId, String apm, Role role) throws IOException, FileManipulationException, ClientAlreadyExistsException, ClientNotFoundException {
        clientId = clientId.toUpperCase();
        apm = apm.toUpperCase();
        if(getRoleForClientForApm(clientId, apm).equals(Role.NONE)) {
            writeLock.lock();
            try {
                getClientForId(clientId).addRoleForApm(apm,role);
                updatePermissionsFile();
            } catch (FileManipulationException | IOException e) {
                getClientForId(clientId).removeRoleForApm(apm);
                throw e;
            } finally {
                writeLock.unlock();
            }
        } else {
            throw new ClientAlreadyExistsException("Role for client on apm exists. For modification please use the modify endpoint to modify an existing role.");
        }
    }

    @Override
    public void modifyRoleForClientForApm(String clientId, String apm, Role role) throws IOException, FileManipulationException, ClientNotFoundException {
        clientId = clientId.toUpperCase();
        apm = apm.toUpperCase();
        if(!getRoleForClientForApm(clientId, apm).equals(Role.NONE)) {
            Role roleBackup = getClientForId(clientId).getRoleForApm(apm);
            writeLock.lock();
            try {
                getClientForId(clientId).addRoleForApm(apm,role);
                updatePermissionsFile();
            } catch (FileManipulationException | IOException e) {
                getClientForId(clientId).addRoleForApm(apm,roleBackup);
                throw e;
            } finally {
                writeLock.unlock();
            }
        } else {
            throw new ClientNotFoundException("No role exists for the given apm for the given user. Please use the add endpoint to add a new role.");
        }
    }

    @Override
    public void removeRoleForClientForApm(String clientId, String apm) throws IOException, FileManipulationException, ClientNotFoundException {
        clientId = clientId.toUpperCase();
        apm = apm.toUpperCase();
        if(!getRoleForClientForApm(clientId, apm).equals(Role.NONE)) {
            Role roleBackup = getClientForId(clientId).getRoleForApm(apm);
            if(!roleBackup.equals(Role.NONE)) {
                writeLock.lock();
                try {
                    getClientForId(clientId).removeRoleForApm(apm);
                    updatePermissionsFile();
                } catch (FileManipulationException | IOException e) {
                    getClientForId(clientId).addRoleForApm(apm,roleBackup);
                    throw e;
                } finally {
                    writeLock.unlock();
                }
            }
        } else {
            throw new ClientNotFoundException("No role exists for the given apm for the given user. ");
        }
    }

    @Override
    public Role getRoleForClientForApm(String clientId, String apm) throws ClientNotFoundException {
        clientId = clientId.toUpperCase();
        apm = apm.toUpperCase();
        readLock.lock();
        try {
            return getClientForId(clientId).getRoleForApm(apm);
        } finally {
            readLock.unlock();
        }
    }

    @Override
    public Map<String, Role> getAllRolesForClient(String clientId) throws ClientNotFoundException {
        clientId = clientId.toUpperCase();
        return getClientForId(clientId).getAllRoles();
    }

    private void updatePermissionsFile() throws FileManipulationException, IOException {
        readLock.lock();
        try {
            try {
                //creating a backup for rollback
                Path copied = Paths.get(permissionsFileLocation + ".bak");
                Path originalPath = Paths.get(permissionsFileLocation);
                Files.copy(originalPath, copied, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                LOG.error("Failed to create backup for permissions.csv: {}", e.getMessage());
                throw new FileManipulationException("Failed to backup permissions file.");
            }

            try {
                PrintWriter pw = new PrintWriter(permissionsFileLocation, Charset.forName("UTF-8"));
                for (Map.Entry<String, Client> clientIterator : clientMap.entrySet()) {
                    for (Map.Entry<String, Role> roleIterator : clientIterator.getValue().getAllRoles().entrySet()) {
                        pw.println(clientIterator.getKey() + separator +
                                roleIterator.getKey() + separator
                                + roleIterator.getValue().name());
                    }

                }
                pw.close();
            } catch (IOException e) {
                LOG.error("Failed to update permissions.csv: {} \nRolling back.", e.getMessage());
                Path copied = Paths.get(permissionsFileLocation);
                Path originalPath = Paths.get(permissionsFileLocation + ".bak");
                try {
                    Files.copy(originalPath, copied, StandardCopyOption.REPLACE_EXISTING);
                    LOG.info("Rollback was successful.");
                } catch (IOException ex) {
                    LOG.error("Rollback was unsuccessful, permissions file is most probably corrupted. Exiting.", ex);
                    throw ex;
                }
                throw new FileManipulationException("Failed to update permissions file.");
            }
        } finally {
            readLock.unlock();
        }

    }

    private void updateClientCredentialsFile() throws FileManipulationException, IOException {
        readLock.lock();
        try {
            try {
                //creating a backup for rollback
                Path copied = Paths.get(credentialsFileLocation + ".bak");
                Path originalPath = Paths.get(credentialsFileLocation);
                Files.copy(originalPath, copied, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                LOG.error("Failed to create backup for credentials.csv: {}", e.getMessage());
                throw new FileManipulationException("Failed to backup credentialsFile.");
            }

            try {
                PrintWriter pw = new PrintWriter(credentialsFileLocation, Charset.forName("UTF-8"));
                for (Map.Entry<String, Client> iterator : clientMap.entrySet()) {
                    pw.println(iterator.getValue().getClientId() + separator + iterator.getValue().getHashedPassword());
                }
                pw.close();
            } catch (IOException e) {
                LOG.error("Failed to update credentials.csv: {} \nRolling back.", e.getMessage());
                Path copied = Paths.get(credentialsFileLocation);
                Path originalPath = Paths.get(credentialsFileLocation + ".bak");
                try {
                    Files.copy(originalPath, copied, StandardCopyOption.REPLACE_EXISTING);
                    LOG.info("Rollback was successful.");
                } catch (IOException ex) {
                    LOG.error("Rollback was unsuccessful, credentials file is most probably corrupted. Exiting.", ex);
                    throw ex;
                }
                throw new FileManipulationException("Failed to update credentialsFile.");
            }
        } finally {
            readLock.unlock();
        }

    }

    private void populateClientsMap() throws IOException, MalformedCredentialsFileException, MalformedPermissionsFileException, FileManipulationException {
        loadClients();
        loadPermissions();
    }

    private void loadClients() throws IOException, MalformedCredentialsFileException {
        HashMap<String, Client> temp = new HashMap<>();
        File file = new File(credentialsFileLocation);
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line = br.readLine();
        int lineNum = 0;
        String columns[];
        while((line != null) && !(line.isEmpty())){
            columns = line.split(separator);
            if(columns.length != 2){
                throw new MalformedCredentialsFileException("In credentials.csv line #" + lineNum + " does not have the correct number of columns (2).");
            }

            String clientId = columns[0].toUpperCase();
            String passwordHash = columns[1];

            if(!temp.containsKey(clientId)){
                temp.put(clientId,new Client(clientId,passwordHash));
            }

            lineNum ++;
            line = br.readLine();
        }

        writeLock.lock();
        try {
            clientMap.clear();
            clientMap.putAll(temp);
        } finally {
            writeLock.unlock();
        }

    }

    private void loadPermissions() throws IOException, MalformedPermissionsFileException, FileManipulationException {

        boolean hasOrphanEntries = false;
        File file = new File(permissionsFileLocation);
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line = br.readLine();
        int lineNum = 1;
        String columns[];
        writeLock.lock();
        try {
            while ((line != null) && !(line.equals(""))) {
                columns = line.split(separator);
                if (columns.length != 3) {
                    throw new MalformedPermissionsFileException("In permissions.csv line #" + lineNum + " does not have the correct number of columns (3).");
                }

                String clientId = columns[0].toUpperCase();
                String apm = columns[1].toUpperCase();
                String roleAsString = columns[2];
                Role role;

                switch (roleAsString) {
                    case "NONE":
                        role = Role.NONE;
                        break;
                    case "READ":
                        role = Role.READ;
                        break;
                    case "WRITE":
                        role = Role.WRITE;
                        break;
                    case "ADMIN":
                        role = Role.ADMIN;
                        break;
                    default:
                        throw new MalformedPermissionsFileException("In permissions.csv line #" + lineNum + " role " + roleAsString + " does not exist.");
                }

                if (clientMap.containsKey(clientId)) {
                    clientMap.get(clientId).addRoleForApm(apm, role);
                } else {
                    hasOrphanEntries = true;
                }

                lineNum++;
                line = br.readLine();
            }
        } finally {
            writeLock.unlock();
        }

        if(hasOrphanEntries){
            updatePermissionsFile();
        }

    }
}
