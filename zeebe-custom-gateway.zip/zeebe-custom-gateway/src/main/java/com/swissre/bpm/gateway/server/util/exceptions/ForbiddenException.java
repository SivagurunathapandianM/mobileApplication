package com.swissre.bpm.gateway.server.util.exceptions;

public class ForbiddenException extends Exception{
    public ForbiddenException(String message) {
        super(message);
    }
}
