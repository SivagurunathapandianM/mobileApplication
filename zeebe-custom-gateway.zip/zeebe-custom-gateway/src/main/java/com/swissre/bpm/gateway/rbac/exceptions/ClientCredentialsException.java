package com.swissre.bpm.gateway.rbac.exceptions;

public class ClientCredentialsException extends Exception {
    public ClientCredentialsException(String message) {
        super(message);
    }
}
