package com.swissre.bpm.gateway.server.util.exceptions;

public class UnauthenticatedException extends AuthException{
    public UnauthenticatedException() {
    }

    public UnauthenticatedException(String message) {
        super(message);
    }
}
