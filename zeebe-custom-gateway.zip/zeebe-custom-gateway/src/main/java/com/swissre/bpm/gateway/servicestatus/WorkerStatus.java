package com.swissre.bpm.gateway.servicestatus;

public enum WorkerStatus {
    UNKNOWN,
    OK,
    UNAUTHENTICATED,
    OFFLINE
}
