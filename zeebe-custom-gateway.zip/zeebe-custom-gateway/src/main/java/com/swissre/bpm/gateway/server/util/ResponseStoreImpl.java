package com.swissre.bpm.gateway.server.util;

import com.google.protobuf.GeneratedMessageV3;
import io.grpc.stub.StreamObserver;

import java.util.concurrent.ConcurrentHashMap;

public class ResponseStoreImpl<T extends GeneratedMessageV3> implements ResponseStore<T>{
    private final ConcurrentHashMap<String, StreamObserver<T>> responseMap = new ConcurrentHashMap<>();

    public void store(String transactionId, StreamObserver<T> responseObserver){
        responseMap.put(transactionId,responseObserver);
    }

    public void respond(String transactionId, T response){

        StreamObserver<T> responseObserver = responseMap.get(transactionId);
        responseMap.remove(transactionId);
        responseObserver.onNext(response);
        responseObserver.onCompleted();

    }

    public void throwError(String transactionId, Throwable t){
        StreamObserver<T> responseObserver = responseMap.get(transactionId);
        responseMap.remove(transactionId);
        responseObserver.onError(t);
    }
}


