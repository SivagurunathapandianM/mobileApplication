package com.swissre.bpm.gateway.server.util;

import com.google.protobuf.GeneratedMessageV3;
import io.grpc.stub.StreamObserver;

public interface ResponseStore<T extends GeneratedMessageV3> {
    void store(String transactionId, StreamObserver<T> responseObserver);
    void respond(String transactionId, T response);
    void throwError(String transactionId, Throwable t);
}
