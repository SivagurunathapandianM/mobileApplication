package com.swissre.bpm.gateway.client;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.swissre.bpm.gateway.caching.ZeebeElementStore;
import com.swissre.bpm.gateway.client.util.HazelcastClientDoesNotExistsException;
import com.swissre.bpm.gateway.client.util.HazelcastClusterUnavailableException;
import com.swissre.bpm.gateway.client.util.HazelcastEntryDoesNotExistException;
import com.swissre.bpm.gateway.client.util.HazelcastEntryMalformedException;
import com.swissre.bpm.gateway.servicestatus.WorkerStatus;
import com.swissre.bpm.gateway.servicestatus.WorkerStatusEntry;
import com.swissre.bpm.gateway.servicestatus.WorkerStatusStore;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class HazelcastImdgClient implements WorkerStatusStore, ZeebeElementStore {

    private static final Logger LOG = LogManager.getLogger(HazelcastImdgClient.class);

    private static final long ONE_MINUTE_IN_MILLIS = 60000;

    private HazelcastInstance client;
    private static boolean hazelcastAvailable = false;
    private long lastClientCreation = 0;
    private final String hazelcastRemoteAddress;
    private final String hazelcastClusterName;
    private final String keySuffixSeparator;

    private final String activeWorkersMap;
    private final String jobKeyMap;
    private final String workflowKeyMap;
    private final String workflowInstanceIdMap;

    private final int cacheEntryTTLSeconds;
    private final int retryConnectionMinutes;

    public HazelcastImdgClient(Properties properties) {

        this.activeWorkersMap = properties.getProperty("hazelcast.ActiveWorkersMap");
        this.jobKeyMap = properties.getProperty("hazelcast.JobKeyMap");
        this.workflowKeyMap = properties.getProperty("hazelcast.WorkflowKeyMap");
        this.workflowInstanceIdMap = properties.getProperty("hazelcast.WorkflowInstanceIdMap");

        this.keySuffixSeparator = properties.getProperty("hazelcast.keySuffixSeparator");
        this.hazelcastClusterName = properties.getProperty("hazelcast.clusterName");
        this.hazelcastRemoteAddress = properties.getProperty("hazelcast.remoteAddress");

        this.cacheEntryTTLSeconds = Integer.parseInt(properties.getProperty("hazelcast.cache.ttl.seconds"));
        this.retryConnectionMinutes = Integer.parseInt(properties.getProperty("hazelcast.retryConnectionMinutes"));

        createClient();
    }

    @Override
    public void putAsync(WorkerStatusEntry input) {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
             return;
            }
        }

        IMap<String, String> map = client.getMap(activeWorkersMap);

        map.putAsync(input.getWorkerId() + keySuffixSeparator + WorkerStatusEntry.workerStatusSuffix,
                input.getWorkerStatus().name());
        map.putAsync(input.getWorkerId() + keySuffixSeparator + WorkerStatusEntry.lastUpdatedTimestampSuffix,
                Long.toString(input.getLastUpdatedTimestamp()));

    }

    @Override
    public WorkerStatusEntry get(String workerId) throws HazelcastEntryDoesNotExistException, HazelcastEntryMalformedException, HazelcastClusterUnavailableException {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
                throw new HazelcastClusterUnavailableException("Can not perform get, hazelcast cluster is unavailable ");
            }
        }

        IMap<String, String> map = client.getMap(activeWorkersMap);
        if (map.containsKey(workerId + keySuffixSeparator + WorkerStatusEntry.workerStatusSuffix) &&
                map.containsKey(workerId + keySuffixSeparator + WorkerStatusEntry.lastUpdatedTimestampSuffix)) {
            try {
                long lastUpdatedTimestamp = Long.parseLong(map.get(workerId + keySuffixSeparator + WorkerStatusEntry.lastUpdatedTimestampSuffix));
                WorkerStatus workerStatus = WorkerStatus.valueOf(map.get(workerId + keySuffixSeparator + WorkerStatusEntry.workerStatusSuffix));
                return new WorkerStatusEntry(workerId, lastUpdatedTimestamp, workerStatus);
            } catch (NumberFormatException e) {
                throw new HazelcastEntryMalformedException("Entry exists with the given key is malformed. lastUpdatedTimestamp is invalid: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                throw new HazelcastEntryMalformedException("Entry exists with the given key is malformed. workerStatus is invalid: " + e.getMessage());
            }
        } else {
            throw new HazelcastEntryDoesNotExistException("No entry exists with the given key in the given map.");
        }

    }

    @Override
    public void putBpmnProcessIdForJobKey(long jobKey, String bpmnProcessId) {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
                return;
            }
        }

        IMap<Long, String> map = client.getMap(jobKeyMap);

        map.putAsync(jobKey, bpmnProcessId, cacheEntryTTLSeconds, TimeUnit.SECONDS);
    }

    @Override
    public void putBpmnProcessIdForWorkflowKey(long workflowKey, String bpmnProcessId) {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
                return;
            }
        }

        IMap<Long, String> map = client.getMap(workflowKeyMap);

        map.putAsync(workflowKey, bpmnProcessId, cacheEntryTTLSeconds, TimeUnit.SECONDS);
    }

    @Override
    public void putBpmnProcessIdForWorkflowInstanceId(long workflowInstanceId, String bpmnProcessId) {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
                return;
            }
        }

        IMap<Long, String> map = client.getMap(workflowInstanceIdMap);

        map.putAsync(workflowInstanceId, bpmnProcessId, cacheEntryTTLSeconds, TimeUnit.SECONDS);
    }

    @Override
    public String getBpmnProcessIdForJobKey(long jobKey) throws HazelcastEntryDoesNotExistException {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
                throw new HazelcastEntryDoesNotExistException("No entry exists with the given key in the given map.");
            }
        }

        IMap<Long, String> map = client.getMap(jobKeyMap);
        if (map.containsKey(jobKey)) {
            return map.get(jobKey);
        } else {
            throw new HazelcastEntryDoesNotExistException("No entry exists with the given key in the given map.");
        }
    }

    @Override
    public String getBpmnProcessIdForWorkflowKey(long workflowKey) throws HazelcastEntryDoesNotExistException {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
                throw new HazelcastEntryDoesNotExistException("No entry exists with the given key in the given map.");
            }
        }

        IMap<Long, String> map = client.getMap(workflowKeyMap);
        if (map.containsKey(workflowKey)) {
            return map.get(workflowKey);
        } else {
            throw new HazelcastEntryDoesNotExistException("No entry exists with the given key in the given map.");
        }
    }

    @Override
    public String getBpmnProcessIdForWorkflowInstanceId(long workflowInstanceId) throws HazelcastEntryDoesNotExistException {
        if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
            hazelcastAvailable = false;
            createClientInSeparateThread();
            if (!hazelcastAvailable || !client.getLifecycleService().isRunning()) {
                throw new HazelcastEntryDoesNotExistException("No entry exists with the given key in the given map.");
            }
        }

        IMap<Long, String> map = client.getMap(workflowInstanceIdMap);
        if (map.containsKey(workflowInstanceId)) {
            return map.get(workflowInstanceId);
        } else {
            throw new HazelcastEntryDoesNotExistException("No entry exists with the given key in the given map.");
        }
    }

    private void createClient() {
        try {
            ClientConfig config = new ClientConfig();
            final var networkConfig = config.getNetworkConfig();
            networkConfig.addAddress(hazelcastRemoteAddress);
            config.setClusterName(hazelcastClusterName);
            client = HazelcastClient.newHazelcastClient(config);
            hazelcastAvailable = true;
        } catch (Exception e) {
            LOG.error("Unable to connect to hazelcast cluster. Retrying in {} minutes", retryConnectionMinutes, e);
            hazelcastAvailable = false;
        }
    }

    private void createClientInSeparateThread() {
        if ((System.currentTimeMillis() - lastClientCreation) > retryConnectionMinutes * ONE_MINUTE_IN_MILLIS) {
            lastClientCreation = System.currentTimeMillis();

            Runnable clientCreatorThread =
                    () -> {
                        try {
                            ClientConfig config = new ClientConfig();
                            final var networkConfig = config.getNetworkConfig();
                            networkConfig.addAddress(hazelcastRemoteAddress);
                            config.setClusterName(hazelcastClusterName);
                            client = HazelcastClient.newHazelcastClient(config);
                            hazelcastAvailable = true;
                        } catch (Exception e) {
                            LOG.error("Unable to connect to hazelcast cluster. Retrying in {} minutes", retryConnectionMinutes, e);
                            hazelcastAvailable = false;
                        }
                    };

            Thread thread = new Thread(clientCreatorThread);
            thread.start();
        }
    }

    public void shutDown() throws HazelcastClientDoesNotExistsException {
        if(client != null) {
            client.shutdown();
        } else {
            throw new HazelcastClientDoesNotExistsException("hazelcast client is null");
        }
    }

    public static boolean isHazelcastAvailable() {
        return hazelcastAvailable;
    }
}
