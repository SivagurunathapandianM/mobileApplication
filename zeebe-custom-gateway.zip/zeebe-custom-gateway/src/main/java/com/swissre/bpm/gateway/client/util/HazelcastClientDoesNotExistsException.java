package com.swissre.bpm.gateway.client.util;

public class HazelcastClientDoesNotExistsException extends HazelcastException {
    public HazelcastClientDoesNotExistsException() {
    }

    public HazelcastClientDoesNotExistsException(String message) {
        super(message);
    }
}
