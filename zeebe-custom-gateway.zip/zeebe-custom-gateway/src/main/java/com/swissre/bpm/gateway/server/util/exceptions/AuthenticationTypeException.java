package com.swissre.bpm.gateway.server.util.exceptions;

public class AuthenticationTypeException extends AuthException {
    public AuthenticationTypeException() {
    }

    public AuthenticationTypeException(String message) {
        super(message);
    }
}
