package com.swissre.bpm.gateway.server.util;

import com.swissre.bpm.gateway.server.util.exceptions.InvalidXmlException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.Map;
import java.util.Set;

public class XmlUtils {

    public static void validateBpmn(byte[] input, boolean isCallActivityHardening, Map<String,Set<String>> whitelistedBpmnProcessIdMappings) throws InvalidXmlException {
        String processIdOfParentWorkflow = getBpmnProcessIdFromXml(input).toUpperCase();
        String apm = extractApmFromEntity(processIdOfParentWorkflow);
        if(apm == null ||apm.isEmpty()){
            throw new InvalidXmlException("No APM part in id of bpmn:process element");
        }
        Document xmlAsXml = getXmlDocumentFromBytes(input);
        String errorOutput = checkTaskTypes(xmlAsXml, apm).trim();
        errorOutput = errorOutput.concat("\n").concat(checkMessages(xmlAsXml, apm)).trim();

        if(isCallActivityHardening) {
            errorOutput = errorOutput.concat("\n").concat(checkCallActivities(xmlAsXml, processIdOfParentWorkflow, whitelistedBpmnProcessIdMappings)).trim();
        }

        if(!errorOutput.isEmpty()){
            throw new InvalidXmlException(errorOutput.trim());
        }
    }

    private static String checkCallActivities(Document document, String processIdOfParentWorkflow, Map<String,Set<String>> whitelistedBpmnProcessIds) {
        String apm = extractApmFromEntity(processIdOfParentWorkflow).toUpperCase();
        String output = "";
        NodeList callActivities = document.getElementsByTagName("zeebe:calledElement");
        for(int i = 0; i < callActivities.getLength(); i++){
            String processIdOfCalledElement = callActivities.item(i).getAttributes().getNamedItem("processId").getTextContent().toUpperCase();
            if (!processIdOfCalledElement.contains(".")){
                output = output.concat("ERROR: No APM part in call activity's processId: " + processIdOfCalledElement +
                        " All call activity's processId should start with your APM as <your APM>.<process id> " +
                        "or should be whitelisted to be able to call a different APM's workflow.\n");
            } else {
                if( whitelistedBpmnProcessIds.containsKey(processIdOfParentWorkflow.toUpperCase()) &&
                        whitelistedBpmnProcessIds.get(processIdOfParentWorkflow.toUpperCase()).contains(processIdOfCalledElement)) {
                    continue;
                }
                if (!extractApmFromEntity(processIdOfCalledElement).toUpperCase().equals(apm.toUpperCase())){
                    output = output.concat("ERROR: APM part of call activity's processId: " + processIdOfCalledElement +
                            " is malformed or does not match the APM in the BPMN process id (" + apm + ")" +
                            " or not whitelisted to call a different APM's workflow.\n");
                }
            }
        }
        return output;
    }

    private static String checkTaskTypes(Document document, String apm) {
        String output = "";
        NodeList taskTypes = document.getElementsByTagName("zeebe:taskDefinition");
        for(int i = 0; i < taskTypes.getLength(); i++){
            try {
                String taskType = taskTypes.item(i).getAttributes().getNamedItem("type").getTextContent();
                if (!taskType.contains(".")){
                    output = output.concat("ERROR: No APM part in type of zeebe:taskDefinition element: " + taskTypes.item(i).toString() + " All task types should start with your APM as <your APM>.<task type> \n");
                } else {
                    if (!extractApmFromEntity(taskType).toUpperCase().equals(apm.toUpperCase())){
                        output = output.concat("ERROR: APM part of task type: " + taskType + " is malformed or does not match the APM in the BPMN process id (" + apm + ").\n");
                    }
                }
            } catch (NullPointerException e) {
                output = output.concat("ERROR: No type defined for zeebe:taskDefinition element at: " + taskTypes.item(i).toString() + "\n");
            }
        }

        return output;
    }

    private static String checkMessages(Document document, String apm) {
        String output = "";
        NodeList messages = document.getElementsByTagName("bpmn:message");
        for(int i = 0; i < messages.getLength(); i++){
            try {
                String messageName = messages.item(i).getAttributes().getNamedItem("name").getTextContent();
                if (!messageName.contains(".")){
                    output = output.concat("ERROR: No APM part in type of bpmn:message element: " + messages.item(i).toString() + " All message names should start with your APM as <your APM>.<message name> \n");
                } else {
                    if (!extractApmFromEntity(messageName).toUpperCase().equals(apm.toUpperCase())){
                        output = output.concat("ERROR: APM part of message name: " + messageName + " is malformed or does not match the APM in the BPMN process id (" + apm + ").\n");
                    }
                }
            } catch (NullPointerException e) {
                output = output.concat("ERROR: No name defined for bpmn:message element at: " + messages.item(i).toString() + "\n");
            }
        }

        return output;
    }

    public static String getBpmnProcessIdFromXml(byte[] input) throws InvalidXmlException {
        Document xmlAsXml = getXmlDocumentFromBytes(input);
        String bpmnProcessId;
        try {
            bpmnProcessId = xmlAsXml.getElementsByTagName("bpmn:process").item(0).getAttributes().getNamedItem("id").getTextContent();
        } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
            throw new InvalidXmlException("Did not managed to find a valid bpmnId in the record.");
        }

        if(bpmnProcessId == null || bpmnProcessId.isEmpty()){
            throw new InvalidXmlException("Did not managed to find bpmnId in the record.");
        }

        return bpmnProcessId;
    }

    public static Document getXmlDocumentFromBytes(byte[] input) throws InvalidXmlException {

        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            return builder.parse(new InputSource(new StringReader(getASCIIStringFromBytes(input))));
        }
        catch (Exception e)
        {
            throw new InvalidXmlException();
        }
    }

    private static String getASCIIStringFromBytes(byte[] input){
        String output = new String();

        for (byte b : input) {
            output = output.concat(((char) b) + "");
        }

        return output;
    }

    private static String extractApmFromEntity(String entity){
        String temp = entity;

        if(entity.startsWith("=\"") && entity.length() >= 3) {
            temp = entity.substring(2);
        }

        if(temp.contains(".")) {
            return temp.split("\\.")[0];
        } else {
            return "";
        }
    }
}