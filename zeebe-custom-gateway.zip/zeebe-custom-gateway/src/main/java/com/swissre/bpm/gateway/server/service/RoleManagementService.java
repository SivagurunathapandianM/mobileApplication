package com.swissre.bpm.gateway.server.service;

import com.swissre.bpm.gateway.rbac.ClientHandler;
import com.swissre.bpm.gateway.rbac.exceptions.ClientAlreadyExistsException;
import com.swissre.bpm.gateway.rbac.exceptions.ClientNotFoundException;
import com.swissre.bpm.gateway.rbac.exceptions.FileManipulationException;
import com.swissre.bpm.gateway.server.auth.AuthorizationHelper;
import com.swissre.bpm.gateway.server.MetadataProcessor;
import com.swissre.bpm.gateway.server.util.exceptions.ForbiddenException;
import com.swissre.bpm.grpc.customgateway.*;
import io.grpc.stub.StreamObserver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class RoleManagementService extends RoleManagementServiceGrpc.RoleManagementServiceImplBase {
    private static final Logger LOG = LogManager.getLogger(RoleManagementService.class);
    private AuthorizationHelper authorizationHelper;

    public RoleManagementService(AuthorizationHelper authorizationHelper) {
        this.authorizationHelper = authorizationHelper;
    }

    @Override
    public void addClientRoleForApm(ClientRoleMessage request, StreamObserver<Status> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        LOG.debug("Adding role {} on apm {} for client {}.",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId().toUpperCase());
        Status response;
        try {
            if(!(authorizationHelper.authorizeBasedOnApm(CLIENT_ID,Role.ADMIN,"ADMIN")
                    || authorizationHelper.authorizeBasedOnApm(CLIENT_ID, Role.ADMIN,request.getApm()))){
                throw new ForbiddenException("Unauthorized");
            }
            ClientHandler.getInstance().addRoleForClientForApm(request.getClientId().getClientId(),request.getApm(),request.getRole());
            LOG.debug("Successfully added role {} on apm {} for client {}.",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId().toUpperCase());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.SUCCESS)
                    .setDescription("Successfully added role.")
                    .build();
        } catch (ForbiddenException e) {
            LOG.error("Failed to add role {} on apm {} for client {}. Cause: {}",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.UNAUTHORIZED)
                    .setDescription(e.getMessage())
                    .build();
        } catch (FileManipulationException | IOException e) {
            LOG.error("Failed to add role {} on apm {} for client {}. Cause: {}",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.INTERNAL_ERROR)
                    .setDescription("Error happened during client role addition.")
                    .build();
        } catch (ClientAlreadyExistsException e) {
            LOG.error("Failed to add role {} on apm {} for client {}. Cause: {}",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.FAILURE)
                    .setDescription(e.getMessage())
                    .build();
        } catch (ClientNotFoundException e) {
            LOG.error("Failed to add role {} on apm {} for client {}. Cause: {}",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.NOT_FOUND)
                    .setDescription(e.getMessage())
                    .build();
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void modifyClientRoleForApm(ClientRoleMessage request, StreamObserver<Status> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        LOG.debug("Modifying role on apm {} for client {} to {}.",request.getApm().toUpperCase(),request.getClientId().getClientId().toUpperCase(),request.getRole().name().toUpperCase());
        Status response;
        try {
            if(!(authorizationHelper.authorizeBasedOnApm(CLIENT_ID,Role.ADMIN,"ADMIN")
                    || authorizationHelper.authorizeBasedOnApm(CLIENT_ID, Role.ADMIN,request.getApm()))){
                throw new ForbiddenException("Unauthorized");
            }
            ClientHandler.getInstance().modifyRoleForClientForApm(request.getClientId().getClientId(),request.getApm(),request.getRole());
            LOG.debug("Successfully modified role {} on apm {} for client {}.",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId().toUpperCase());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.SUCCESS)
                    .setDescription("Successfully added role.")
                    .build();
        } catch (ForbiddenException e) {
            LOG.error("Failed to modify role {} on apm {} for client {}. Cause: {}",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.UNAUTHORIZED)
                    .setDescription(e.getMessage())
                    .build();
        } catch (FileManipulationException | IOException e) {
            LOG.error("Failed to modify role {} on apm {} for client {}. Cause: {}",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.INTERNAL_ERROR)
                    .setDescription("Error happened during client role modification.")
                    .build();
        } catch (ClientNotFoundException e) {
            LOG.error("Failed to modify role {} on apm {} for client {}. Cause: {}",request.getRole().name().toUpperCase(),request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.NOT_FOUND)
                    .setDescription(e.getMessage())
                    .build();
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void revokeClientRoleForApm(RevokeRoleMessage request, StreamObserver<Status> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        LOG.debug("Revoking role on apm {} for client {}.",request.getApm().toUpperCase(),request.getClientId().getClientId().toUpperCase());
        Status response;
        try {
            if(!(authorizationHelper.authorizeBasedOnApm(CLIENT_ID,Role.ADMIN,"ADMIN")
                    || authorizationHelper.authorizeBasedOnApm(CLIENT_ID, Role.ADMIN,request.getApm()))){
                throw new ForbiddenException("Unauthorized");
            }
            ClientHandler.getInstance().removeRoleForClientForApm(request.getClientId().getClientId(),request.getApm());
            LOG.debug("Successfully revoked role on apm {} for client {}.",request.getApm().toUpperCase(),request.getClientId().getClientId().toUpperCase());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.SUCCESS)
                    .setDescription("Successfully revoked role.")
                    .build();
        } catch (ForbiddenException e) {
            LOG.error("Failed to revoke role on apm {} for client {}. Cause: {}",request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.UNAUTHORIZED)
                    .setDescription(e.getMessage())
                    .build();
        } catch (FileManipulationException | IOException e) {
            LOG.error("Failed to revoke role on apm {} for client {}. Cause: {}",request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.INTERNAL_ERROR)
                    .setDescription("Error happened during client role addition.")
                    .build();
        } catch (ClientNotFoundException e) {
            LOG.error("Failed to revoke role on apm {} for client {}. Cause: {}",request.getApm().toUpperCase(),request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.NOT_FOUND)
                    .setDescription(e.getMessage())
                    .build();
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getClientRoles(ClientId request, StreamObserver<GetClientRolesResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        LOG.debug("Listing roles for client with id {}.",request.getClientId());
        GetClientRolesResponse response;
        try {
            if (!(authorizationHelper.authorizeBasedOnApm(CLIENT_ID, Role.ADMIN, "ADMIN")
                    || CLIENT_ID.toUpperCase().equals(request.getClientId().toUpperCase()))) {
                throw new ForbiddenException("Unauthorized");
            }

            Map<String, Role> clientRoles = ClientHandler.getInstance().getAllRolesForClient(CLIENT_ID);
            List<RoleMessage> clientRolesForResponse= new ArrayList<>();

            for(Map.Entry<String, Role> iterator : clientRoles.entrySet()){
                clientRolesForResponse.add(RoleMessage.newBuilder()
                        .setApm(iterator.getKey())
                        .setRole(iterator.getValue())
                        .build());
            }

            response = GetClientRolesResponse.newBuilder()
                    .setStatus(Status.newBuilder()
                            .setStatusCode(StatusCode.SUCCESS)
                            .build())
                    .addAllRoles(clientRolesForResponse)
                    .build();
        } catch (ForbiddenException e) {
            LOG.error("Failed to list roles for client {}. Cause: {}",request.getClientId(),e.getMessage());
            response = GetClientRolesResponse.newBuilder()
                    .setStatus(Status.newBuilder()
                            .setStatusCode(StatusCode.UNAUTHORIZED)
                            .setDescription(e.getMessage())
                            .build())
                    .build();
        } catch (ClientNotFoundException e) {
            LOG.error("Failed to list roles for client {}. Cause: {}",request.getClientId(),e.getMessage());
            response = GetClientRolesResponse.newBuilder()
                    .setStatus(Status.newBuilder()
                            .setStatusCode(StatusCode.NOT_FOUND)
                            .setDescription("Failed to list roles for client. Cause: " + e.getMessage())
                            .build())
                    .build();
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
