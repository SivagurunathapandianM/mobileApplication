package com.swissre.bpm.gateway.client.util;

public abstract class HazelcastException extends Exception {
    public HazelcastException() {
    }

    public HazelcastException(String message) {
        super(message);
    }

    public HazelcastException(String message, Throwable cause) {
        super(message, cause);
    }

    public HazelcastException(Throwable cause) {
        super(cause);
    }
}
