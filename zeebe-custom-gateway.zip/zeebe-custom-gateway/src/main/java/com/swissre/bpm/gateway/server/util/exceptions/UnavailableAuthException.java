package com.swissre.bpm.gateway.server.util.exceptions;

public class UnavailableAuthException extends AuthException{
    public UnavailableAuthException() {
    }

    public UnavailableAuthException(String message) {
        super(message);
    }
}
