package com.swissre.bpm.gateway.rbac;

import com.swissre.bpm.gateway.rbac.exceptions.ClientAlreadyExistsException;
import com.swissre.bpm.gateway.rbac.exceptions.ClientNotFoundException;
import com.swissre.bpm.gateway.rbac.exceptions.FileManipulationException;
import com.swissre.bpm.grpc.customgateway.Role;

import java.io.IOException;
import java.util.Map;

public interface PermissionHandler {

    void addRoleForClientForApm(String clientId, String apm, Role role) throws IOException, FileManipulationException, ClientAlreadyExistsException, ClientNotFoundException;

    void modifyRoleForClientForApm(String clientId, String apm, Role role) throws IOException, FileManipulationException, ClientNotFoundException;

    void removeRoleForClientForApm(String clientId, String apm) throws IOException, FileManipulationException, ClientNotFoundException;

    Role getRoleForClientForApm(String clientId, String apm) throws ClientNotFoundException;

    Map<String, Role> getAllRolesForClient(String clientId) throws ClientNotFoundException;
}
