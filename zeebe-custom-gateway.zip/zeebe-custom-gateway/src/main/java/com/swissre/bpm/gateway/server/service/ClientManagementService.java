package com.swissre.bpm.gateway.server.service;

import com.swissre.bpm.gateway.rbac.ClientHandler;
import com.swissre.bpm.gateway.rbac.exceptions.*;
import com.swissre.bpm.gateway.server.auth.AuthorizationHelper;
import com.swissre.bpm.gateway.server.MetadataProcessor;
import com.swissre.bpm.gateway.server.util.exceptions.ForbiddenException;
import com.swissre.bpm.grpc.customgateway.*;
import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import io.grpc.stub.StreamObserver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.Properties;

public class ClientManagementService extends ClientManagementServiceGrpc.ClientManagementServiceImplBase {

    private static final Logger LOG = LogManager.getLogger(ClientManagementService.class);
    private AuthorizationHelper authorizationHelper;
    private int argonIterations;
    private int argonMemoryKibibytes;
    private int argonParallelism;

    public ClientManagementService(AuthorizationHelper authorizationHelper, Properties appProps) {
        this.authorizationHelper = authorizationHelper;
        argonIterations = Integer.parseInt(appProps.getProperty("argon.iterations"));
        argonMemoryKibibytes = Integer.parseInt(appProps.getProperty("argon.memoryKibibytes"));
        argonParallelism = Integer.parseInt(appProps.getProperty("argon.parallelism"));
    }

    @Override
    public void registerClient(ClientCredentialsMessage request, StreamObserver<Status> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        LOG.debug("Registering client with id {}.",request.getClientId().getClientId());
        Status response;
        try {
            if(!authorizationHelper.authorizeBasedOnApm(CLIENT_ID,Role.ADMIN,"ADMIN")){
                throw new ForbiddenException("Unauthorized");
            }
            ClientHandler.getInstance().addClientCredentials(request.getClientId().getClientId(),hashPassword(request.getPassword()));
            LOG.debug("Successful client registration for id {}.",request.getClientId().getClientId());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.SUCCESS)
                    .setDescription("Successfully registered client.")
                    .build();
        } catch (FileManipulationException | IOException e) {
            LOG.error("Failed to register client for id {}.",request.getClientId().getClientId(),e);
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.INTERNAL_ERROR)
                    .setDescription("Fatal exception happened during client registration.")
                    .build();
        } catch (ClientAlreadyExistsException e) {
            LOG.error("Failed to register client for id {}. Cause: {}",request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.FAILURE)
                    .setDescription("Failed to register new client. Cause: " + e.getMessage())
                    .build();
        } catch (ForbiddenException e) {
            LOG.error("Failed to register client for id {}. Cause: {}",request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.UNAUTHORIZED)
                    .setDescription(e.getMessage())
                    .build();
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void changePassword(ClientCredentialsMessage request, StreamObserver<Status> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        LOG.debug("Changing password for client with id {}.",request.getClientId().getClientId());
        Status response;
        try {
            if(!(authorizationHelper.authorizeBasedOnApm(CLIENT_ID,Role.ADMIN,"ADMIN")
                    || CLIENT_ID.toUpperCase().equals(request.getClientId().getClientId().toUpperCase()))){
                throw new ForbiddenException("Unauthorized");
            }
            ClientHandler.getInstance().modifyClientCredentials(request.getClientId().getClientId(),hashPassword(request.getPassword()));
            LOG.debug("Successful client password change for id {}.",request.getClientId().getClientId());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.SUCCESS)
                    .setDescription("Successfully changed client password.")
                    .build();
        } catch (FileManipulationException | IOException e) {
            LOG.error("Failed to change client password for id {}.",request.getClientId().getClientId(),e);
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.INTERNAL_ERROR)
                    .setDescription("Fatal exception happened during password change.")
                    .build();
        } catch (ClientNotFoundException e) {
            LOG.error("Failed to change client password for id {}. Cause: {}",request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.NOT_FOUND)
                    .setDescription("Fatal exception happened during password change. Cause: "+e.getMessage())
                    .build();
        } catch (ForbiddenException e) {
            LOG.error("Failed to change client password for id {}. Cause: {}",request.getClientId().getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.UNAUTHORIZED)
                    .setDescription(e.getMessage())
                    .build();
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void removeClient(ClientId request, StreamObserver<Status> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        Status response;
        LOG.debug("Removing client with id {}.",request.getClientId());
        try {
            if(!(authorizationHelper.authorizeBasedOnApm(CLIENT_ID,Role.ADMIN,"ADMIN")
                    || CLIENT_ID.toUpperCase().equals(request.getClientId().toUpperCase()))){
                throw new ForbiddenException("Unauthorized");
            }
            ClientHandler.getInstance().removeClientCredentials(request.getClientId());
            LOG.debug("Successful client removal for id {}.",request.getClientId());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.SUCCESS)
                    .setDescription("Successfully removed client.")
                    .build();
        } catch (FileManipulationException | IOException e) {
            LOG.error("Failed to remove client {}.",request.getClientId(),e);
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.INTERNAL_ERROR)
                    .setDescription("Fatal exception happened during client removal.")
                    .build();
        } catch (ClientNotFoundException e) {
            LOG.error("Failed to remove client {}. Cause: {}",request.getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.NOT_FOUND)
                    .setDescription("Failed to remove new client. Cause: " + e.getMessage())
                    .build();
        }  catch (ForbiddenException e) {
            LOG.error("Failed to remove client {}. Cause: {}",request.getClientId(),e.getMessage());
            response = Status.newBuilder()
                    .setStatusCode(StatusCode.UNAUTHORIZED)
                    .setDescription(e.getMessage())
                    .build();
        }
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    private String hashPassword(String password){
        Argon2 argon2 = Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);
        return argon2.hash(argonIterations,argonMemoryKibibytes,argonParallelism,password.toCharArray());
    }
}
