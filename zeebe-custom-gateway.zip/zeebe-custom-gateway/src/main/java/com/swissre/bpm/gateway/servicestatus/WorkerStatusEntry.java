package com.swissre.bpm.gateway.servicestatus;

public class WorkerStatusEntry {

    private String workerId;
    private long lastUpdatedTimestamp;
    private WorkerStatus workerStatus;

    public final static String lastUpdatedTimestampSuffix = "lastUpdatedTimestamp";
    public final static String workerStatusSuffix = "workerStatus";

    public WorkerStatusEntry(String workerId, long lastUpdatedTimestamp, WorkerStatus workerStatus) {
        this.workerId = workerId;
        this.lastUpdatedTimestamp = lastUpdatedTimestamp;
        this.workerStatus = workerStatus;
    }

    public String getWorkerId() {
        return workerId;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public long getLastUpdatedTimestamp() {
        return lastUpdatedTimestamp;
    }

    public void setLastUpdatedTimestamp(long lastUpdatedTimestamp) {
        this.lastUpdatedTimestamp = lastUpdatedTimestamp;
    }

    public WorkerStatus getWorkerStatus() {
        return workerStatus;
    }

    public void setWorkerStatus(WorkerStatus workerStatus) {
        this.workerStatus = workerStatus;
    }

}
