package com.swissre.bpm.gateway.server.util.exceptions;

public class AuthorizationUnavailableException extends AuthException {

    public AuthorizationUnavailableException() {
        super();
    }

    public AuthorizationUnavailableException(String message) {
        super(message);
    }
}
