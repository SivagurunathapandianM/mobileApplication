package com.swissre.bpm.gateway.client.util;

public class HazelcastEntryMalformedException extends HazelcastException{
    public HazelcastEntryMalformedException() {
    }

    public HazelcastEntryMalformedException(String message) {
        super(message);
    }
}
