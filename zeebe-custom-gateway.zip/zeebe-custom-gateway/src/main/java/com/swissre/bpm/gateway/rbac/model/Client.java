package com.swissre.bpm.gateway.rbac.model;

import com.swissre.bpm.grpc.customgateway.Role;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Client {

    private String clientId;
    private String hashedPassword;
    private Map<String, Role> roles = new HashMap<>();

    private Client() {
    }

    public Client(String clientId, String hashedPassword) {
        this.clientId = clientId;
        this.hashedPassword = hashedPassword;
    }

    public String getHashedPassword() {
        return hashedPassword;
    }

    public void setHashedPassword(String hashedPassword) {
        this.hashedPassword = hashedPassword;
    }

    public String getClientId() {
        return clientId;
    }

    public Role getRoleForApm(String apm){
        return roles.getOrDefault(apm, Role.NONE);
    }

    public void removeRoleForApm(String apm){
        roles.remove(apm);
    }

    public void addRoleForApm(String apm, Role role){
        roles.put(apm,role);
    }

    public Map<String, Role> getAllRoles(){
        return roles;
    }
}
