package com.swissre.bpm.gateway.rbac.model;

import com.swissre.bpm.grpc.customgateway.Role;

import java.util.Comparator;

public class RoleComparator implements Comparator<Role> {
    @Override
    public int compare(Role o1, Role o2) {
        return o1.getNumber() - o2.getNumber();
    }
}
