package com.swissre.bpm.gateway.server.util.exceptions;

public class MalformedRequestContentException extends AuthException{
    public MalformedRequestContentException() {
    }

    public MalformedRequestContentException(String message) {
        super(message);
    }
}
