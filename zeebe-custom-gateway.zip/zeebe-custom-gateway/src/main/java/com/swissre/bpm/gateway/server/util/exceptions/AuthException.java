package com.swissre.bpm.gateway.server.util.exceptions;

public abstract class AuthException extends  Exception{

    public AuthException() {
    }

    public AuthException(String message) {
        super(message);
    }

}
