package com.swissre.bpm.gateway.servicestatus;

import com.swissre.bpm.gateway.client.util.HazelcastException;

public interface WorkerStatusStore {

    /**
     * Inserts two new entries:
     *  * lastUpdatedTimestamp
     *  * workerStatus
     *
     * The key used is made out of the workers id plus the suffix for the given field:
     *  * {@link com.swissre.bpm.gateway.servicestatus.WorkerStatusEntry#lastUpdatedTimestampSuffix} suffix for lastUpdatedTimestamp
     *  * {@link com.swissre.bpm.gateway.servicestatus.WorkerStatusEntry#workerStatusSuffix} suffix for workerStatus
     * @param input The object to be inserted.
     */
    void putAsync(WorkerStatusEntry input);

    /**
     * Fetches and parses the value for the given key.
     * @param workerId The key.
     * @return The fetched value parsed as a WorkerStatusEntry.
     * @throws HazelcastException Throws HazelcastEntryDoesNotExistException if the given key (workerId) is not in the map.
     */
    WorkerStatusEntry get(String workerId) throws HazelcastException;

}
