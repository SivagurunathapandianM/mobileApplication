package com.swissre.bpm.gateway;


import com.swissre.bpm.gateway.client.HazelcastImdgClient;
import com.swissre.bpm.gateway.client.RocksDbExtractorClient;
import com.swissre.bpm.gateway.client.util.HazelcastClientDoesNotExistsException;
import com.swissre.bpm.gateway.rbac.ClientHandler;
import com.swissre.bpm.gateway.rbac.exceptions.FileManipulationException;
import com.swissre.bpm.gateway.rbac.exceptions.MalformedCredentialsFileException;
import com.swissre.bpm.gateway.rbac.exceptions.MalformedPermissionsFileException;
import com.swissre.bpm.gateway.rbac.exceptions.ResourceNotFoundException;
import com.swissre.bpm.gateway.server.GrpcServer;
import com.swissre.bpm.gateway.servicestatus.HealthCheckApp;
import io.grpc.StatusRuntimeException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.Properties;


public class ZeebeCustomGateway {


    private static final Logger LOG = LogManager.getLogger(ZeebeCustomGateway.class);

    public static void main(String[] args) throws IOException, InterruptedException, MalformedPermissionsFileException, ResourceNotFoundException, MalformedCredentialsFileException, FileManipulationException {
			HazelcastImdgClient hazelcastImdgClient = null;
			HealthCheckApp healthCheckApp = null;

	    	try {
				Properties properties = loadProperties();
				ClientHandler.getInstance().init(properties);

				hazelcastImdgClient = new HazelcastImdgClient(properties);
				RocksDbExtractorClient rocksDbExtractorClient = new RocksDbExtractorClient(properties, hazelcastImdgClient);
				healthCheckApp = new HealthCheckApp(
						properties.getProperty("healthCheck.rootPath"),
						Integer.parseInt(properties.getProperty("healthCheck.port")),
						properties.getProperty("brokerClient.brokerHost") + ":" + properties.getProperty("brokerClient.brokerPort"),
						properties.getProperty("version"),
						rocksDbExtractorClient);
				healthCheckApp.startServer();

				GrpcServer grpcServer = new GrpcServer(properties);
				grpcServer.start(hazelcastImdgClient, rocksDbExtractorClient);
				LOG.info("Zeebe Custom Gateway started.");
				grpcServer.blockUntilShutdown();
			} catch (StatusRuntimeException ex) {
				//TODO add metrics to help detecting issues
			} finally {
				if (hazelcastImdgClient != null) {
					try {
						hazelcastImdgClient.shutDown();
					} catch (HazelcastClientDoesNotExistsException e) {
						System.exit(1);
					}
				}
				if (healthCheckApp != null) {
					healthCheckApp.stopServer();
				}
			}
    }

    private static Properties loadProperties() throws IOException {
        Properties appProps = new Properties();
        appProps.load(ZeebeCustomGateway.class.getClassLoader().getResourceAsStream("Gateway.properties"));
        String environment = System.getenv("ENVIRONMENT");
        if (environment != null && !environment.isEmpty()) {
            switch (environment) {
                case "LOCAL":
                    appProps.put("brokerClient.usePlainText", appProps.get("brokerClient.LOCAL.usePlainText"));
                    appProps.put("brokerClient.brokerHost", appProps.get("brokerClient.LOCAL.brokerHost"));
                    appProps.put("brokerClient.brokerPort", appProps.get("brokerClient.LOCAL.brokerPort"));

                    appProps.put("rocksDbExtractor.host", appProps.get("rocksDbExtractor.LOCAL.host"));
                    appProps.put("rocksDbExtractor.port", appProps.get("rocksDbExtractor.LOCAL.port"));

                    appProps.put("files.credentialsFileLocation", appProps.get("files.LOCAL.credentialsFileLocation"));
                    appProps.put("files.permissionsFileLocation", appProps.get("files.LOCAL.permissionsFileLocation"));
            }
        }
        LOG.info("Properties loaded: \n{}", appProps);
        return appProps;
    }

}
