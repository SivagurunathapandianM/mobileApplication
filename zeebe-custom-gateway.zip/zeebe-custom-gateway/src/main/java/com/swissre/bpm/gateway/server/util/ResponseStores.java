package com.swissre.bpm.gateway.server.util;

import com.google.protobuf.GeneratedMessageV3;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import java.util.concurrent.ConcurrentHashMap;

public class ResponseStores {

    public enum ResponseType {
        CancelWorkflowInstanceResponse,
        CompleteJobResponse,
        CreateWorkflowInstanceResponse,
        CreateWorkflowInstanceWithResultResponse,
        DeployWorkflowResponse,
        FailJobResponse,
        ThrowErrorResponse,
        PublishMessageResponse,
        ResolveIncidentResponse,
        TopologyResponse,
        UpdateJobRetriesResponse,
        SetVariablesResponse
    }


    private static ResponseStores INSTANCE;

    private final ConcurrentHashMap<ResponseType, ResponseStore<? extends GeneratedMessageV3>> responseStores = new ConcurrentHashMap<>();

    public synchronized static ResponseStores getInstance(){
        if(INSTANCE == null){
            INSTANCE = new ResponseStores();
        }
        return INSTANCE;
    }

    private ResponseStores(){
        responseStores.put(ResponseType.CancelWorkflowInstanceResponse, new ResponseStoreImpl<GatewayOuterClass.CancelWorkflowInstanceResponse>());
        responseStores.put(ResponseType.CompleteJobResponse, new ResponseStoreImpl<GatewayOuterClass.CompleteJobResponse>());
        responseStores.put(ResponseType.CreateWorkflowInstanceResponse, new ResponseStoreImpl<GatewayOuterClass.CreateWorkflowInstanceResponse>());
        responseStores.put(ResponseType.CreateWorkflowInstanceWithResultResponse, new ResponseStoreImpl<GatewayOuterClass.CreateWorkflowInstanceWithResultResponse>());
        responseStores.put(ResponseType.DeployWorkflowResponse, new ResponseStoreImpl<GatewayOuterClass.DeployWorkflowResponse>());
        responseStores.put(ResponseType.FailJobResponse, new ResponseStoreImpl<GatewayOuterClass.FailJobResponse>());
        responseStores.put(ResponseType.ThrowErrorResponse, new ResponseStoreImpl<GatewayOuterClass.ThrowErrorResponse>());
        responseStores.put(ResponseType.PublishMessageResponse, new ResponseStoreImpl<GatewayOuterClass.PublishMessageResponse>());
        responseStores.put(ResponseType.ResolveIncidentResponse, new ResponseStoreImpl<GatewayOuterClass.ResolveIncidentResponse>());
        responseStores.put(ResponseType.TopologyResponse, new ResponseStoreImpl<GatewayOuterClass.TopologyResponse>());
        responseStores.put(ResponseType.UpdateJobRetriesResponse, new ResponseStoreImpl<GatewayOuterClass.UpdateJobRetriesResponse>());
        responseStores.put(ResponseType.SetVariablesResponse, new ResponseStoreImpl<GatewayOuterClass.SetVariablesResponse>());
    }

    public <T extends GeneratedMessageV3> ResponseStore<T> get(ResponseType responseType) {
        return (ResponseStore<T>) responseStores.get(responseType);
    }
}
