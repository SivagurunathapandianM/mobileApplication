package com.swissre.bpm.gateway.rbac.exceptions;

public class ClientUnauthorizedException extends ClientCredentialsException {
    public ClientUnauthorizedException(String message) {
        super(message);
    }
}
