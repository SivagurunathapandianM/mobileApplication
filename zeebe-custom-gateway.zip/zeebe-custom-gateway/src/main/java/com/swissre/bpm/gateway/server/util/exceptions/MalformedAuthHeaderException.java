package com.swissre.bpm.gateway.server.util.exceptions;

public class MalformedAuthHeaderException extends AuthException {
    public MalformedAuthHeaderException() {
    }

    public MalformedAuthHeaderException(String message) {
        super(message);
    }
}
