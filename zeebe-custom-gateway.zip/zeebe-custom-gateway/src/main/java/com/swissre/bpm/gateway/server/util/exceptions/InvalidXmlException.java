package com.swissre.bpm.gateway.server.util.exceptions;

public class InvalidXmlException extends  Exception{
    public InvalidXmlException() {
    }

    public InvalidXmlException(String message) {
        super(message);
    }
}
