package com.swissre.bpm.gateway.server.util.exceptions;

public class UnknownAuthException extends AuthException{
    public UnknownAuthException() {
    }

    public UnknownAuthException(String message) {
        super(message);
    }
}
