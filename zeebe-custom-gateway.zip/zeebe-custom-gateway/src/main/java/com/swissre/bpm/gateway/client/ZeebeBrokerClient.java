package com.swissre.bpm.gateway.client;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.swissre.bpm.gateway.server.util.ResponseStores;
import io.grpc.ManagedChannelBuilder;
import io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.NettyChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.zeebe.gateway.protocol.GatewayGrpc;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

import javax.net.ssl.SSLException;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ZeebeBrokerClient {
    private static final Logger LOG = LogManager.getLogger(com.swissre.bpm.gateway.client.ZeebeBrokerClient.class);

    private GatewayGrpc.GatewayBlockingStub blockingStubTowardsBroker;
    private GatewayGrpc.GatewayStub stubTowardsBroker;
    private GatewayGrpc.GatewayFutureStub futureStubTowardsBroker;
    private int grpcDeadline;

    private ExecutorService executorService;

    public ZeebeBrokerClient(String brokerHost, int brokerPort, File certChain, File privateKey, int grpcDeadline, int clientExecutorThreadPoolSize) throws SSLException {
        LOG.info("ZeebeBrokerClient towards address: {}:{} with TLS on", brokerHost,brokerPort);
        this.executorService = Executors.newFixedThreadPool(clientExecutorThreadPoolSize);
        this.grpcDeadline = grpcDeadline;
        SslContextBuilder builder = GrpcSslContexts.forClient();
        builder.keyManager(certChain,privateKey);

        SslContext sslContext = builder.build();

        blockingStubTowardsBroker = GatewayGrpc.newBlockingStub(NettyChannelBuilder
                .forAddress(brokerHost,brokerPort)
                .sslContext(sslContext)
                .useTransportSecurity()
                .build());

        stubTowardsBroker = GatewayGrpc.newStub(NettyChannelBuilder
                .forAddress(brokerHost,brokerPort)
                .sslContext(sslContext)
                .useTransportSecurity()
                .build());

        futureStubTowardsBroker = GatewayGrpc.newFutureStub(NettyChannelBuilder
                .forAddress(brokerHost,brokerPort)
                .sslContext(sslContext)
                .useTransportSecurity()
                .build());

    }

    public ZeebeBrokerClient(String brokerHost, int brokerPort, int grpcDeadline, int clientExecutorThreadPoolSize) {
        LOG.info("ZeebeBrokerClient towards address: {}:{}", brokerHost,brokerPort);
        this.executorService = Executors.newFixedThreadPool(clientExecutorThreadPoolSize);
        this.grpcDeadline = grpcDeadline;

        blockingStubTowardsBroker = GatewayGrpc.newBlockingStub(ManagedChannelBuilder
                .forAddress(brokerHost,brokerPort)
                .usePlaintext()
                .build());

        stubTowardsBroker = GatewayGrpc.newStub(NettyChannelBuilder
                .forAddress(brokerHost,brokerPort)
                .usePlaintext()
                .build());

        futureStubTowardsBroker = GatewayGrpc.newFutureStub(NettyChannelBuilder
                .forAddress(brokerHost,brokerPort)
                .usePlaintext()
                .build());
    }

    public void activateJobs(GatewayOuterClass.ActivateJobsRequest request, StreamObserver<GatewayOuterClass.ActivateJobsResponse> streamObserver) {
        executorService.submit(() -> stubTowardsBroker
                .withDeadlineAfter(8*grpcDeadline,TimeUnit.SECONDS)
                .activateJobs(request, streamObserver));
    }

    public void cancelWorkflowInstance(String transactionId, GatewayOuterClass.CancelWorkflowInstanceRequest request) {

        ListenableFuture<GatewayOuterClass.CancelWorkflowInstanceResponse> listenableResponse = futureStubTowardsBroker
                        .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                        .cancelWorkflowInstance(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.CancelWorkflowInstanceResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CancelWorkflowInstanceResponse>get(ResponseStores.ResponseType.CancelWorkflowInstanceResponse)
                        .respond(transactionId,result);
                LOG.debug("cancelWorkflowInstance rpc workflowInstance: {} got completed successfully. transactionId: {}",
                        request.getWorkflowInstanceKey(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("cancelWorkflowInstance rpc on workflowInstance: {} failed due to a StatusRuntimeException: {} transactionId: {}",request.getWorkflowInstanceKey(),t.getMessage(),transactionId);
                 ResponseStores.getInstance()
                         .<GatewayOuterClass.CancelWorkflowInstanceResponse>get(ResponseStores.ResponseType.CancelWorkflowInstanceResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);

    }

    public void completeJob(String transactionId, GatewayOuterClass.CompleteJobRequest request) {

        ListenableFuture<GatewayOuterClass.CompleteJobResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .completeJob(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.CompleteJobResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CompleteJobResponse>get(ResponseStores.ResponseType.CompleteJobResponse)
                        .respond(transactionId,result);
                LOG.debug("completeJob rpc on job: {} got completed successfully. transactionId: {}",
                        request.getJobKey(), transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("completeJob rpc on job: {} failed due to a StatusRuntimeException: {} transactionId: {} ",request.getJobKey(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CompleteJobResponse>get(ResponseStores.ResponseType.CompleteJobResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void createWorkflowInstance(String transactionId, GatewayOuterClass.CreateWorkflowInstanceRequest request) {
        ListenableFuture<GatewayOuterClass.CreateWorkflowInstanceResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .createWorkflowInstance(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.CreateWorkflowInstanceResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CreateWorkflowInstanceResponse>get(ResponseStores.ResponseType.CreateWorkflowInstanceResponse)
                        .respond(transactionId,result);
                LOG.debug("createWorkflowInstance rpc for bpmnProcessId: {} got completed successfully. transactionId: {}",request.getBpmnProcessId(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("createWorkflowInstance rpc for bpmnProcessId: {} failed due to a StatusRuntimeException: {} transactionId: {} ",request.getBpmnProcessId(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CreateWorkflowInstanceResponse>get(ResponseStores.ResponseType.CreateWorkflowInstanceResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void createWorkflowInstanceWithResult(String transactionId, GatewayOuterClass.CreateWorkflowInstanceWithResultRequest request) {
        ListenableFuture<GatewayOuterClass.CreateWorkflowInstanceWithResultResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .createWorkflowInstanceWithResult(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.CreateWorkflowInstanceWithResultResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CreateWorkflowInstanceWithResultResponse>get(ResponseStores.ResponseType.CreateWorkflowInstanceWithResultResponse)
                        .respond(transactionId,result);
                LOG.debug("createWorkflowInstanceWithResult rpc on bpmnProcessId: {} got completed successfully. transactionId: {}",request.getRequest().getBpmnProcessId(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("createWorkflowInstanceWithResult rpc for bpmnProcessId: {} failed due to a StatusRuntimeException: {} transactionId: {}",request.getRequest().getBpmnProcessId(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CreateWorkflowInstanceWithResultResponse>get(ResponseStores.ResponseType.CreateWorkflowInstanceWithResultResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void throwError(String transactionId, GatewayOuterClass.ThrowErrorRequest request) {
        ListenableFuture<GatewayOuterClass.ThrowErrorResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .throwError(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.ThrowErrorResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.ThrowErrorResponse>get(ResponseStores.ResponseType.ThrowErrorResponse)
                        .respond(transactionId,result);
                LOG.debug("throwError rpc on job: {} got completed successfully. transactionId: {}",request.getJobKey(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("throwError rpc for job: {} failed due to a StatusRuntimeException: {} transactionId: {} ",request.getJobKey(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.ThrowErrorResponse>get(ResponseStores.ResponseType.ThrowErrorResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void deployWorkflow(String transactionId, GatewayOuterClass.DeployWorkflowRequest request) {
        ListenableFuture<GatewayOuterClass.DeployWorkflowResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .deployWorkflow(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.DeployWorkflowResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.DeployWorkflowResponse>get(ResponseStores.ResponseType.DeployWorkflowResponse)
                        .respond(transactionId,result);
                LOG.debug("deployWorkflow rpc completed successfully. transactionId: {}",transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("deployWorkflow rpc failed due to a StatusRuntimeException: {}. Transaction id: {} transactionId: {}",transactionId,t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.DeployWorkflowResponse>get(ResponseStores.ResponseType.DeployWorkflowResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void failJob(String transactionId, GatewayOuterClass.FailJobRequest request) {
        ListenableFuture<GatewayOuterClass.FailJobResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .failJob(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.FailJobResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.FailJobResponse>get(ResponseStores.ResponseType.FailJobResponse)
                        .respond(transactionId,result);
                LOG.debug("failJob rpc on job: {} got completed successfully. transactionId: {}",request.getJobKey(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("failJob rpc for job: {} failed due to a StatusRuntimeException: {} transactionId: {} ",request.getJobKey(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.FailJobResponse>get(ResponseStores.ResponseType.FailJobResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void publishMessage(String transactionId, GatewayOuterClass.PublishMessageRequest request) {
        ListenableFuture<GatewayOuterClass.PublishMessageResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .publishMessage(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.PublishMessageResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.PublishMessageResponse>get(ResponseStores.ResponseType.PublishMessageResponse)
                        .respond(transactionId,result);
                LOG.debug("publishMessage rpc for messageName: {} got completed successfully. transactionId: {}",request.getName(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("publishMessage rpc for messageName: {} failed due to a StatusRuntimeException: {}  transactionId: {}",request.getName(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.PublishMessageResponse>get(ResponseStores.ResponseType.PublishMessageResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void resolveIncident(String transactionId, GatewayOuterClass.ResolveIncidentRequest request) {
        ListenableFuture<GatewayOuterClass.ResolveIncidentResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .resolveIncident(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.ResolveIncidentResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.ResolveIncidentResponse>get(ResponseStores.ResponseType.ResolveIncidentResponse)
                        .respond(transactionId,result);
                LOG.debug("resolveIncident rpc got completed successfully. transactionId: {}",transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("resolveIncident rpc for incidentKey: {} failed due to a StatusRuntimeException: {}  transactionId: {}",request.getIncidentKey(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.ResolveIncidentResponse>get(ResponseStores.ResponseType.ResolveIncidentResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void setVariables(String transactionId, GatewayOuterClass.SetVariablesRequest request) {
        ListenableFuture<GatewayOuterClass.SetVariablesResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .setVariables(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.SetVariablesResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.SetVariablesResponse>get(ResponseStores.ResponseType.SetVariablesResponse)
                        .respond(transactionId,result);
                LOG.debug("setVariables rpc for elementInstanceKey: {} got completed successfully. transactionId: {}",request.getElementInstanceKey(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("setVariables rpc for elementInstanceKey: {} failed due to a StatusRuntimeException: {} transactionId: {}",request.getElementInstanceKey(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.SetVariablesResponse>get(ResponseStores.ResponseType.SetVariablesResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    public void topology(String transactionId, GatewayOuterClass.TopologyRequest request) {
        ListenableFuture<GatewayOuterClass.TopologyResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .topology(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.TopologyResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.TopologyResponse>get(ResponseStores.ResponseType.TopologyResponse)
                        .respond(transactionId,result);
                LOG.debug("topology rpc got completed successfully. transactionId: {}",transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("topology rpc failed due to a StatusRuntimeException: {} transactionId: {}",t.getMessage(), transactionId);
                ResponseStores.getInstance()
                        .<GatewayOuterClass.TopologyResponse>get(ResponseStores.ResponseType.TopologyResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }

    /**
     *  Only for the rocksdb extractor client
     */
    public GatewayOuterClass.TopologyResponse topologyBlocking(GatewayOuterClass.TopologyRequest request) {
        return blockingStubTowardsBroker.withDeadlineAfter(grpcDeadline, TimeUnit.SECONDS).topology(request);
    }

    public void updateJobRetries(String transactionId, GatewayOuterClass.UpdateJobRetriesRequest request) {
        ListenableFuture<GatewayOuterClass.UpdateJobRetriesResponse> listenableResponse = futureStubTowardsBroker
                .withDeadlineAfter(grpcDeadline,TimeUnit.SECONDS)
                .updateJobRetries(request);

        Futures.addCallback(listenableResponse, new FutureCallback<>() {
            @Override
            public void onSuccess(GatewayOuterClass.UpdateJobRetriesResponse result) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.UpdateJobRetriesResponse>get(ResponseStores.ResponseType.UpdateJobRetriesResponse)
                        .respond(transactionId,result);
                LOG.debug("updateJobRetries rpc on job: {} got completed successfully. transactionId: {}",request.getJobKey(),transactionId);
            }

            @Override
            public void onFailure(@NotNull Throwable t) {
                LOG.error("updateJobRetries rpc for job: {} failed due to a StatusRuntimeException: {} transactionId: {}",request.getJobKey(),t.getMessage(),transactionId);
                ResponseStores.getInstance()
                         .<GatewayOuterClass.UpdateJobRetriesResponse>get(ResponseStores.ResponseType.UpdateJobRetriesResponse)
                         .throwError(transactionId,t);
            }
        }, executorService);
    }
}
