package com.swissre.bpm.gateway.caching;

import com.swissre.bpm.gateway.client.util.HazelcastException;

public interface ZeebeElementStore {

    /**
     *
     * @param jobKey
     * @param bpmnProcessId
     */
    void putBpmnProcessIdForJobKey(long jobKey, String bpmnProcessId);

    /**
     *
     * @param workflowKey
     * @param bpmnProcessId
     */
    void putBpmnProcessIdForWorkflowKey(long workflowKey, String bpmnProcessId);

    /**
     *
     * @param workflowInstanceId
     * @param bpmnProcessId
     */
    void putBpmnProcessIdForWorkflowInstanceId(long workflowInstanceId, String bpmnProcessId);

    /**
     *
     * @param jobKey
     * @return bpmnProcessId
     */
    String getBpmnProcessIdForJobKey(long jobKey) throws HazelcastException;

    /**
     *
     * @param workflowKey
     * @return bpmnProcessId
     */
    String getBpmnProcessIdForWorkflowKey(long workflowKey) throws HazelcastException;

    /**
     *
     * @param workflowInstanceId
     * @return
     */
    String getBpmnProcessIdForWorkflowInstanceId(long workflowInstanceId) throws HazelcastException;

}
