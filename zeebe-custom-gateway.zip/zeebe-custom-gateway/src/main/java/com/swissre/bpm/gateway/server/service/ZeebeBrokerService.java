package com.swissre.bpm.gateway.server.service;

import com.swissre.bpm.gateway.caching.ZeebeElementStore;
import com.swissre.bpm.gateway.client.ZeebeBrokerClient;
import com.swissre.bpm.gateway.server.auth.AuthorizationHelper;
import com.swissre.bpm.gateway.server.MetadataProcessor;
import com.swissre.bpm.gateway.server.util.ResponseStores;
import com.swissre.bpm.gateway.server.util.UUIDHelper;
import com.swissre.bpm.gateway.server.util.XmlUtils;
import com.swissre.bpm.gateway.server.util.exceptions.*;
import com.swissre.bpm.grpc.customgateway.Role;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;
import io.zeebe.gateway.protocol.GatewayGrpc;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ZeebeBrokerService extends GatewayGrpc.GatewayImplBase {
    private static final Logger LOG = LogManager.getLogger(ZeebeBrokerService.class);

    private final ZeebeBrokerClient clientTowardsBroker;
    private final AuthorizationHelper authorizationHelper;
    private final boolean isCallActivityHardening;
    private final Map<String,Set<String>> whitelistedBpmnProcessIdMappings;
    private final ZeebeElementStore zeebeElementStore;
    private final ExecutorService cacheWriter;
    
    public ZeebeBrokerService(ZeebeBrokerClient clientTowardsBroker,
                              AuthorizationHelper authorizationHelper,
                              ZeebeElementStore zeebeElementStore,
                              Properties properties) {
        this.clientTowardsBroker = clientTowardsBroker;
        this.authorizationHelper = authorizationHelper;
        this.isCallActivityHardening = Boolean.parseBoolean(properties.getProperty("auth.isCallActivityHardening"));
        this.zeebeElementStore = zeebeElementStore;
        this.cacheWriter = Executors.newFixedThreadPool(Integer.parseInt(properties.getProperty("brokerService.cacheWriter.threadPoolSize")));

        this.whitelistedBpmnProcessIdMappings = new HashMap<>();
        List<String> mappings = Arrays.asList(properties.getProperty("auth.whitelistedBpmnProcessIdMappings").toUpperCase()
                .split(properties.getProperty("auth.whitelistedBpmnProcessIdMappings.separator.line")));
        for(String iterator : mappings) {
            String parentId = iterator.split(properties.getProperty("auth.whitelistedBpmnProcessIdMappings.separator.mapping"))[0].toUpperCase();
            String targetIds = iterator.split(properties.getProperty("auth.whitelistedBpmnProcessIdMappings.separator.mapping"))[1].toUpperCase();
            whitelistedBpmnProcessIdMappings.put(
                    parentId,
                    new HashSet<String>(Arrays.asList(targetIds.split(properties.getProperty("auth.whitelistedBpmnProcessIdMappings.separator.targetIds"))))
            );
        }
    }

    @Override
    public void activateJobs(GatewayOuterClass.ActivateJobsRequest request, StreamObserver<GatewayOuterClass.ActivateJobsResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.debug("activateJobs rpc got called by user: {} for jobType: {} transactionId: {}", CLIENT_ID, request.getType(),transactionId);
        try {
            if(authorizationHelper.authorizeBasedOnJobType(CLIENT_ID,Role.WRITE,request.getType()) && CLIENT_ID.equals(request.getType())){
                clientTowardsBroker.activateJobs(request, new StreamObserver<GatewayOuterClass.ActivateJobsResponse>() {
                    @Override
                    public void onNext(GatewayOuterClass.ActivateJobsResponse response) {
                        LOG.debug("activateJobs rpc got response: {} transactionId: {}", response,transactionId);

                        cacheWriter.submit(() -> {
                            for(GatewayOuterClass.ActivatedJob activatedJob : response.getJobsList()) {
                                zeebeElementStore.putBpmnProcessIdForJobKey(activatedJob.getKey(),activatedJob.getBpmnProcessId());
                            }
                        });

                        responseObserver.onNext(response);
                    }

                    @Override
                    public void onError(Throwable t) {
                        LOG.debug("activateJobs rpc called by user: {} for jobType: {} got error: {} transactionId: {}", CLIENT_ID, request.getType(), t.getMessage(),transactionId);
                        responseObserver.onError(t);
                    }

                    @Override
                    public void onCompleted() {
                        LOG.debug("activateJobs rpc called by user: {} for jobType: {} got completed transactionId: {}", CLIENT_ID, request.getType(),transactionId);
                        responseObserver.onCompleted();
                    }
                });
            } else {
                if(CLIENT_ID.equals(request.getType())) {
                    LOG.debug("activateJobs rpc called by user: {} for jobType: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getType(),transactionId);
                    responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
                } else {
                    LOG.debug("Can not activate jobs if the clientId does not match the jobType. called by user: {} for jobType: {}  transactionId: {}", CLIENT_ID, request.getType(),transactionId);
                    responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden, clientId does not match the jobType.").asException());
                }
            }
        } catch (MalformedRequestContentException e) {
            LOG.debug("activateJobs rpc called by user: {} for jobType: {} failed due to an auth related issue: {}  transactionId: {}",CLIENT_ID,request.getType(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("activateJobs rpc called by user: {} for jobType: {} failed due to a StatusRuntimeException: {} transactionId: {}",CLIENT_ID,request.getType(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void cancelWorkflowInstance(GatewayOuterClass.CancelWorkflowInstanceRequest request, StreamObserver<GatewayOuterClass.CancelWorkflowInstanceResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("cancelWorkflowInstance rpc got called by user: {} on workflowInstance: {} transactionId: {}", CLIENT_ID, request.getWorkflowInstanceKey(),transactionId);
        try {
            if(authorizationHelper.authorizeBasedOnWorkflowInstanceId(CLIENT_ID, Role.WRITE,request.getWorkflowInstanceKey())){

                ResponseStores.getInstance()
                        .<GatewayOuterClass.CancelWorkflowInstanceResponse>get(ResponseStores.ResponseType.CancelWorkflowInstanceResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.cancelWorkflowInstance(transactionId, request);
            } else {
                LOG.info("cancelWorkflowInstance rpc called by user: {} on workflowInstance: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getWorkflowInstanceKey(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }

        } catch (NotFoundException e) {
            LOG.info("cancelWorkflowInstance rpc called by user: {} on workflowInstance: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getWorkflowInstanceKey(),e.toString(),transactionId);
            responseObserver.onError(Status.NOT_FOUND.withDescription("Can not find the given instance: " + request.getWorkflowInstanceKey() +".  transactionId: " + transactionId).asException());
        } catch (MalformedRequestContentException e) {
            LOG.info("cancelWorkflowInstance rpc called by user: {} on workflowInstance: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getWorkflowInstanceKey(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnknownAuthException e) {
            LOG.error("cancelWorkflowInstance rpc called by user: {} on workflowInstance: {} failed due to an unknown auth related issue. transactionId: {}",CLIENT_ID,request.getWorkflowInstanceKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch ( UnavailableAuthException e) {
            LOG.error("cancelWorkflowInstance rpc called by user: {} on workflowInstance: {} failed due to the unavailability of an auth component. transactionId: {}",CLIENT_ID,request.getWorkflowInstanceKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("cancelWorkflowInstance rpc called by user: {} on workflowInstance: {} failed due to a StatusRuntimeException: {} transactionId: {}",CLIENT_ID,request.getWorkflowInstanceKey(),e.toString(),transactionId);
            responseObserver.onError(e);
        }

    }

    @Override
    public void completeJob(GatewayOuterClass.CompleteJobRequest request, StreamObserver<GatewayOuterClass.CompleteJobResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("completeJob rpc got called by user: {} on job: {} transactionId: {}", CLIENT_ID,request.getJobKey(),transactionId);
        try {
            if (authorizationHelper.authorizeBasedOnJobKey(CLIENT_ID, Role.WRITE, request.getJobKey())) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CompleteJobResponse>get(ResponseStores.ResponseType.CompleteJobResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.completeJob(transactionId, request);
            } else {
                LOG.info("completeJob rpc called by user: {} on job: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (NotFoundException e) {
            LOG.info("completeJob rpc called by user: {} on job: {} authorization failed due to jobKey was not found in rocksdb: {} CONTINUING WITHOUT AUTHORIZATION transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            ResponseStores.getInstance()
                    .<GatewayOuterClass.CompleteJobResponse>get(ResponseStores.ResponseType.CompleteJobResponse)
                    .store(transactionId,responseObserver);

            clientTowardsBroker.completeJob(transactionId, request);
//            responseObserver.onError(Status.NOT_FOUND.withDescription("Can not find the given job: " + request.getJobKey() +".  transactionId: " + transactionId).asException());
        } catch (MalformedRequestContentException e) {
            LOG.info("completeJob rpc called by user: {} on job: {} failed due to an auth related issue: {} transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnknownAuthException e) {
            LOG.error("completeJob rpc called by user: {} on job: {} failed due to an unknown auth related issue. transactionId: {} ",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnavailableAuthException e) {
            LOG.error("completeJob rpc called by user: {} on job: {} failed due to the unavailability of an auth component. transactionId: {} ",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("completeJob rpc called by user: {} on job: {} failed due to a StatusRuntimeException: {} transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void createWorkflowInstance(GatewayOuterClass.CreateWorkflowInstanceRequest request, StreamObserver<GatewayOuterClass.CreateWorkflowInstanceResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("createWorkflowInstance rpc got called by user: {} for bpmnProcessId: {} transactionId: {}", CLIENT_ID,request.getBpmnProcessId(),transactionId);
        try {
            if(authorizationHelper.authorizeBasedOnBpmnProcessId(CLIENT_ID, Role.WRITE, request.getBpmnProcessId())){
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CreateWorkflowInstanceResponse>get(ResponseStores.ResponseType.CreateWorkflowInstanceResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.createWorkflowInstance(transactionId, request);
            } else {
                LOG.info("createWorkflowInstance rpc called by user: {} for bpmnProcessId: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getBpmnProcessId(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (MalformedRequestContentException e) {
            LOG.info("createWorkflowInstance rpc called by user: {} for bpmnProcessId: {} failed due to an auth related issue: {} transactionId: {} ",CLIENT_ID,request.getBpmnProcessId(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("createWorkflowInstance rpc called by user: {} for bpmnProcessId: {} failed due to a StatusRuntimeException: {} transactionId: {} ",CLIENT_ID,request.getBpmnProcessId(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void createWorkflowInstanceWithResult(GatewayOuterClass.CreateWorkflowInstanceWithResultRequest request, StreamObserver<GatewayOuterClass.CreateWorkflowInstanceWithResultResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("createWorkflowInstanceWithResult rpc got called by user:{} for bpmnProcessId: {} transactionId: {}",CLIENT_ID,request.getRequest().getBpmnProcessId(),transactionId);
        try {
            if(authorizationHelper.authorizeBasedOnBpmnProcessId(CLIENT_ID, Role.WRITE, request.getRequest().getBpmnProcessId())) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.CreateWorkflowInstanceWithResultResponse>get(ResponseStores.ResponseType.CreateWorkflowInstanceWithResultResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.createWorkflowInstanceWithResult(transactionId, request);

            } else {
                LOG.info("createWorkflowInstanceWithResult rpc called by user: {} for bpmnProcessId: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getRequest().getBpmnProcessId(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (MalformedRequestContentException e) {
            LOG.info("createWorkflowInstanceWithResult rpc called by user: {} for bpmnProcessId: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getRequest().getBpmnProcessId(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("createWorkflowInstanceWithResult rpc called by user: {} for bpmnProcessId: {} failed due to a StatusRuntimeException: {} transactionId: {}",CLIENT_ID,request.getRequest().getBpmnProcessId(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void throwError(GatewayOuterClass.ThrowErrorRequest request, StreamObserver<GatewayOuterClass.ThrowErrorResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("throwError rpc got called by user: {} for job: {} transactionId: {}", CLIENT_ID, request.getJobKey(),transactionId);
        try {
            if (authorizationHelper.authorizeBasedOnJobKey(CLIENT_ID, Role.WRITE, request.getJobKey())) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.ThrowErrorResponse>get(ResponseStores.ResponseType.ThrowErrorResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.throwError(transactionId, request);

            } else {
                LOG.info("throwError rpc called by user: {} for job: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (NotFoundException e) {
            LOG.info("throwError rpc called by user: {} on job: {} authorization failed due to jobKey was not found in rocksdb: {} CONTINUING WITHOUT AUTHORIZATION transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            ResponseStores.getInstance()
                    .<GatewayOuterClass.ThrowErrorResponse>get(ResponseStores.ResponseType.ThrowErrorResponse)
                    .store(transactionId,responseObserver);

            clientTowardsBroker.throwError(transactionId, request);
//            responseObserver.onError(Status.NOT_FOUND.withDescription("Can not find the given job: " + request.getJobKey() +".  transactionId: " + transactionId).asException());
        } catch (MalformedRequestContentException e) {
            LOG.info("throwError rpc called by user: {} for job: {} failed due to an auth related issue: {} transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnknownAuthException e) {
            LOG.error("throwError rpc called by user: {} for job: {} failed due to an unknown auth related issue. transactionId: {} ",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnavailableAuthException e) {
            LOG.error("throwError rpc called by user: {} for job: {} failed due to the unavailability of an auth component. transactionId: {} ",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("throwError rpc called by user: {} for job: {} failed due to a StatusRuntimeException: {} transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void deployWorkflow(GatewayOuterClass.DeployWorkflowRequest request, StreamObserver<GatewayOuterClass.DeployWorkflowResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("deployWorkflow rpc got called by user: {} transactionId: {}", CLIENT_ID,transactionId);
        for(GatewayOuterClass.WorkflowRequestObject iterator : request.getWorkflowsList()){
            try {
                String bpmnProcessId = XmlUtils.getBpmnProcessIdFromXml(iterator.getDefinition().toByteArray());
                if(!authorizationHelper.authorizeBasedOnBpmnProcessId(CLIENT_ID, Role.WRITE, bpmnProcessId)){
                    LOG.info("deployWorkflow rpc called by user: {} for bpmnProcessId: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,bpmnProcessId,transactionId);
                    responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
                    return;
                }
                XmlUtils.validateBpmn(iterator.getDefinition().toByteArray(),isCallActivityHardening,whitelistedBpmnProcessIdMappings);
            } catch (MalformedRequestContentException | InvalidXmlException e) {
                LOG.info("deployWorkflow rpc called by user: {} failed due to containing an invalid workflow. Transaction id: {}. Error: {} transactionId: {}" , CLIENT_ID,transactionId,e.getMessage(),transactionId);
                responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
                return;
            }
        }

        try {
            ResponseStores.getInstance()
                    .<GatewayOuterClass.DeployWorkflowResponse>get(ResponseStores.ResponseType.DeployWorkflowResponse)
                    .store(transactionId,responseObserver);

            clientTowardsBroker.deployWorkflow(transactionId, request);
        } catch (StatusRuntimeException e) {
            LOG.error("deployWorkflow rpc called by user: {} failed due to a StatusRuntimeException: {}. Transaction id: {} transactionId: {}",CLIENT_ID,transactionId,e.toString(),transactionId);
            responseObserver.onError(e);
        }

    }

    @Override
    public void failJob(GatewayOuterClass.FailJobRequest request, StreamObserver<GatewayOuterClass.FailJobResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("failJob rpc got called by user: {} for job: {} transactionId: {}", CLIENT_ID,request.getJobKey(),transactionId);
        try {
            if (authorizationHelper.authorizeBasedOnJobKey(CLIENT_ID, Role.WRITE, request.getJobKey())) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.FailJobResponse>get(ResponseStores.ResponseType.FailJobResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.failJob(transactionId, request);

            } else {
                LOG.info("failJob rpc called by user: {} for job: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (NotFoundException e) {
            LOG.info("failJob rpc called by user: {} on job: {} authorization failed due to jobKey was not found in rocksdb: {} CONTINUING WITHOUT AUTHORIZATION transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            ResponseStores.getInstance()
                    .<GatewayOuterClass.FailJobResponse>get(ResponseStores.ResponseType.FailJobResponse)
                    .store(transactionId,responseObserver);

            clientTowardsBroker.failJob(transactionId, request);
//            responseObserver.onError(Status.NOT_FOUND.withDescription("Can not find the given job: " + request.getJobKey() +".  transactionId: " + transactionId).asException());
        } catch (MalformedRequestContentException e) {
            LOG.info("failJob rpc called by user: {} for job: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnknownAuthException e) {
            LOG.error("failJob rpc called by user: {} for job: {} failed due to an unknown auth related issue. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnavailableAuthException e) {
            LOG.error("failJob rpc called by user: {} for job: {} failed due to the unavailability of an auth component. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("failJob rpc called by user: {} for job: {} failed due to a StatusRuntimeException: {} transactionId: {} ",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void publishMessage(GatewayOuterClass.PublishMessageRequest request, StreamObserver<GatewayOuterClass.PublishMessageResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("publishMessage rpc got called by user: {} for messageName {}. transactionId: {}", CLIENT_ID, request.getName(),transactionId);
        try {
            if(authorizationHelper.authorizeBasedOnMessageName(CLIENT_ID,Role.WRITE,request.getName())){
                ResponseStores.getInstance()
                        .<GatewayOuterClass.PublishMessageResponse>get(ResponseStores.ResponseType.PublishMessageResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.publishMessage(transactionId, request);

            } else {
                LOG.info("publishMessage rpc called by user: {} for messageName: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getName(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (MalformedRequestContentException e) {
            LOG.info("publishMessage rpc called by user: {} for messageName: {} failed due to an auth related issue: {}  transactionId: {}",CLIENT_ID,request.getName(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("publishMessage rpc called by user: {} for messageName: {} failed due to a StatusRuntimeException: {}  transactionId: {}",CLIENT_ID,request.getName(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void resolveIncident(GatewayOuterClass.ResolveIncidentRequest request, StreamObserver<GatewayOuterClass.ResolveIncidentResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("resolveIncident rpc got called by user: {} transactionId: {}", CLIENT_ID,transactionId);
        //TODO cant authorize, it should be based on what?
        try {
////        if(authorizationHelper.(CLIENT_ID,request.){
            ResponseStores.getInstance()
                    .<GatewayOuterClass.ResolveIncidentResponse>get(ResponseStores.ResponseType.ResolveIncidentResponse)
                    .store(transactionId,responseObserver);

            clientTowardsBroker.resolveIncident(transactionId, request);
////
////        } else {
////            responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
////        }
        } catch (StatusRuntimeException e) {
            LOG.error("resolveIncident rpc called by user: {} for incidentKey: {} failed due to a StatusRuntimeException: {}  transactionId: {}",CLIENT_ID,request.getIncidentKey(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void setVariables(GatewayOuterClass.SetVariablesRequest request, StreamObserver<GatewayOuterClass.SetVariablesResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("setVariables rpc got called by user: {} for elementInstanceKey: {} transactionId: {}", CLIENT_ID,request.getElementInstanceKey(),transactionId);
        try {
            if(authorizationHelper.authorizeBasedOnElementInstanceKey(CLIENT_ID,Role.WRITE,request.getElementInstanceKey())){

                ResponseStores.getInstance()
                        .<GatewayOuterClass.SetVariablesResponse>get(ResponseStores.ResponseType.SetVariablesResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.setVariables(transactionId, request);

            } else {
                LOG.info("setVariables rpc called by user: {} for elementInstanceKey: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getElementInstanceKey(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (MalformedRequestContentException e) {
            LOG.info("setVariables rpc called by user: {} for elementInstanceKey: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getElementInstanceKey(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (NotFoundException e) {
            LOG.info("setVariables rpc called by user: {} for elementInstanceKey: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getElementInstanceKey(),e.toString(),transactionId);
            responseObserver.onError(Status.NOT_FOUND.withDescription("Can not find the given instance: " + request.getElementInstanceKey() +".  transactionId: " + transactionId).asException());
        } catch (UnknownAuthException e) {
            LOG.error("setVariables rpc called by user: {} for elementInstanceKey: {} failed due to an unknown auth related issue. transactionId: {}",CLIENT_ID,request.getElementInstanceKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnavailableAuthException e) {
            LOG.error("setVariables rpc called by user: {} for elementInstanceKey: {} failed due to the unavailability of an auth component. transactionId: {}",CLIENT_ID,request.getElementInstanceKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("setVariables rpc called by user: {} for elementInstanceKey: {} failed due to a StatusRuntimeException: {} transactionId: {}",CLIENT_ID,request.getElementInstanceKey(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void topology(GatewayOuterClass.TopologyRequest request, StreamObserver<GatewayOuterClass.TopologyResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("topology rpc got called by user: {} transactionId: {}", CLIENT_ID ,transactionId);
        try {
            ResponseStores.getInstance()
                    .<GatewayOuterClass.TopologyResponse>get(ResponseStores.ResponseType.TopologyResponse)
                    .store(transactionId,responseObserver);

            clientTowardsBroker.topology(transactionId, request);
            LOG.info("topology rpc called by user: {} got completed successfully. transactionId: {}", CLIENT_ID, transactionId);

        } catch (StatusRuntimeException e) {
            LOG.error("topology rpc called by user: {} failed due to a StatusRuntimeException: {} transactionId: {}",CLIENT_ID,e.toString(), transactionId);
            responseObserver.onError(e);
        }
    }

    @Override
    public void updateJobRetries(GatewayOuterClass.UpdateJobRetriesRequest request, StreamObserver<GatewayOuterClass.UpdateJobRetriesResponse> responseObserver) {
        String CLIENT_ID = MetadataProcessor.userIdContextKey.get();
        String transactionId = UUIDHelper.getUUID();
        LOG.info("updateJobRetries rpc got called by user: {} for job: {} transactionId: {}", CLIENT_ID,request.getJobKey(),transactionId);
        try {
            if (authorizationHelper.authorizeBasedOnJobKey(CLIENT_ID, Role.WRITE, request.getJobKey())) {
                ResponseStores.getInstance()
                        .<GatewayOuterClass.UpdateJobRetriesResponse>get(ResponseStores.ResponseType.UpdateJobRetriesResponse)
                        .store(transactionId,responseObserver);

                clientTowardsBroker.updateJobRetries(transactionId, request);

                LOG.info("updateJobRetries rpc called by user: {} on job: {} got completed successfully. transactionId: {}", CLIENT_ID,request.getJobKey(),transactionId);

            } else {
                LOG.info("updateJobRetries rpc called by user: {} for job: {} failed due to the given user has insufficient privileges. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId);
                responseObserver.onError(Status.PERMISSION_DENIED.withDescription("Forbidden.").asException());
            }
        } catch (NotFoundException e) {
            LOG.info("updateJobRetries rpc called by user: {} for job: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(Status.NOT_FOUND.withDescription("Can not find the given job: " + request.getJobKey() +".  transactionId: " + transactionId).asException());
        } catch (MalformedRequestContentException e) {
            LOG.info("updateJobRetries rpc called by user: {} for job: {} failed due to an auth related issue: {} transactionId: {}",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (UnknownAuthException e) {
            LOG.error("updateJobRetries rpc called by user: {} for job: {} failed due to an unknown auth related issue. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        }  catch (UnavailableAuthException e) {
            LOG.error("updateJobRetries rpc called by user: {} for job: {} failed due to the unavailability of an auth component. transactionId: {}",CLIENT_ID,request.getJobKey(),transactionId,e);
            responseObserver.onError(Status.INTERNAL.withDescription(e.getMessage() + " transactionId: " + transactionId).asException());
        } catch (StatusRuntimeException e) {
            LOG.error("updateJobRetries rpc called by user: {} for job: {} failed due to a StatusRuntimeException: {} transactionId: {}",CLIENT_ID,request.getJobKey(),e.toString(),transactionId);
            responseObserver.onError(e);
        }
    }

}
