package com.swissre.bpm.gateway.server.util;

public class UUIDHelper {
    public static String getUUID(){
        return java.util.UUID.randomUUID().toString();
    }
}
