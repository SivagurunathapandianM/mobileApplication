package com.swissre.bpm.gateway.rbac.exceptions;

public class FileManipulationException extends Exception{
    public FileManipulationException(String message) {
        super(message);
    }
}