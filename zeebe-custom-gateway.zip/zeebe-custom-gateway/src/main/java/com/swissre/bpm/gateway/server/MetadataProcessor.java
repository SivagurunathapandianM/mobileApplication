package com.swissre.bpm.gateway.server;

import com.swissre.bpm.gateway.rbac.ClientHandler;
import com.swissre.bpm.gateway.rbac.exceptions.ClientNotFoundException;
import com.swissre.bpm.gateway.rbac.model.UnsafeClientCredentials;
import com.swissre.bpm.gateway.server.util.exceptions.AuthenticationTypeException;
import com.swissre.bpm.gateway.server.util.exceptions.MalformedAuthHeaderException;
import com.swissre.bpm.gateway.server.util.exceptions.UnauthenticatedException;
import com.swissre.bpm.gateway.servicestatus.WorkerStatus;
import com.swissre.bpm.gateway.servicestatus.WorkerStatusEntry;
import com.swissre.bpm.gateway.servicestatus.WorkerStatusStore;
import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import io.grpc.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;

public class MetadataProcessor implements ServerInterceptor {

    private static final Logger LOG = LogManager.getLogger(MetadataProcessor.class);

    static final Metadata.Key<String> AUTHORIZATION_METADATA_KEY=
            Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER);
    static final String USER_ID_CONTEXT_KEY_STRING = "USER_ID_CONTEXT_KEY";
    public static final Context.Key<String> userIdContextKey = Context.key(USER_ID_CONTEXT_KEY_STRING);

    private final WorkerStatusStore workerStatusStore;

    public MetadataProcessor(WorkerStatusStore workerStatusStore) {
        this.workerStatusStore = workerStatusStore;
    }

    @Override
    public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(
            ServerCall<ReqT, RespT> call,
            final Metadata requestHeaders,
            ServerCallHandler<ReqT, RespT> next) {

        String authorizationHeader = requestHeaders.get(AUTHORIZATION_METADATA_KEY);

        if(authorizationHeader == null || authorizationHeader.isEmpty()){
            call.close(Status.INVALID_ARGUMENT,new Metadata());
            return new ServerCall.Listener<ReqT>() {};
        }

        UnsafeClientCredentials currentClient;
        try {
            currentClient = getCurrentClient(authorizationHeader);
        } catch (AuthenticationTypeException | MalformedAuthHeaderException e) {
            call.close(Status.UNAUTHENTICATED.withDescription(e.getMessage()),new Metadata());
            return new ServerCall.Listener<ReqT>() {};
        }

        long currentTimeMillis = System.currentTimeMillis();

        try {
            authenticateClient(currentClient);
            workerStatusStore.putAsync(new WorkerStatusEntry(currentClient.getClientId(), currentTimeMillis, WorkerStatus.OK));
        }catch (UnauthenticatedException e) {
            call.close(Status.UNAUTHENTICATED.withDescription(e.getMessage()),new Metadata());
            workerStatusStore.putAsync(new WorkerStatusEntry(currentClient.getClientId(), currentTimeMillis, WorkerStatus.UNAUTHENTICATED));
            return new ServerCall.Listener<ReqT>() {};
        }

        Context context = Context
                .current()
                .withValue(userIdContextKey, currentClient.getClientId());

        return Contexts.interceptCall(context,call,requestHeaders,next);
    }

    private UnsafeClientCredentials getCurrentClient(String authorizationHeader) throws AuthenticationTypeException, MalformedAuthHeaderException {
        if (authorizationHeader != null && authorizationHeader.toLowerCase().startsWith("basic")) {
            // Authorization: Basic base64credentials
            String base64Credentials = authorizationHeader.substring("Basic".length()).trim();
            byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
            String credentials = new String(credDecoded, StandardCharsets.UTF_8);

            if(credentials.split(":").length == 2) {
                // credentials = username:password
                String userId = credentials.split(":", 2)[0];
                String password = credentials.split(":", 2)[1];
                return new UnsafeClientCredentials(userId, password);
            } else {
                throw new MalformedAuthHeaderException("Auth header must contain a clientId and its password.");
            }
        } else {
            throw new AuthenticationTypeException("Only basic authentication is accepted.");
        }
    }

    private void authenticateClient(UnsafeClientCredentials client) throws UnauthenticatedException {
        Argon2 argon2 = Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);

        try {
            if(!argon2.verify(ClientHandler.getInstance().getPasswordHashForClient(client.getClientId()),client.getPlainTextPassword().toCharArray())){
                throw new UnauthenticatedException("Invalid credentials.");
            }
        } catch (ClientNotFoundException e) {
            throw new UnauthenticatedException("Invalid credentials.");
        }
    }

}
