package com.swissre.bpm.gateway.servicestatus;

import com.google.gson.JsonObject;
import com.swissre.bpm.gateway.client.HazelcastImdgClient;
import com.swissre.bpm.gateway.client.RocksDbExtractorClient;
import com.swissre.bpm.grpc.rocksdbextractor.BpmnProcessIdMessage;
import com.swissre.bpm.grpc.rocksdbextractor.WorkflowInstanceIdMessage;
import io.grpc.ManagedChannelBuilder;
import io.javalin.Javalin;
import io.zeebe.gateway.protocol.GatewayGrpc;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;

import java.util.concurrent.TimeUnit;

public class HealthCheckApp {

    private final String rootPath;
    private final  int port;
    private Javalin healthCheckApp;
    private final  String brokerContactPoint;
    private final  String version;

    private boolean isHealthy = false;
    private String zeeBeBrokerConnectionStatus = "";
    private boolean isHazelcastAvailable = false;
    private final RocksDbExtractorClient rocksDbExtractorClient;

    public HealthCheckApp(String rootPath, int port, String brokerContactPoint, String version, RocksDbExtractorClient rocksDbExtractorClient) {
        this.rootPath = rootPath;
        this.port = port;
        this.brokerContactPoint = brokerContactPoint;
        this.version = version;
        this.rocksDbExtractorClient = rocksDbExtractorClient;

    }

    public void startServer() {
        Server server = new Server();
        ServerConnector connector = new ServerConnector(server);
        connector.setHost("0.0.0.0");
        connector.setPort(port);
        server.setConnectors(new ServerConnector[]{connector});
        healthCheckApp = Javalin.create(config -> config.server(() -> server)).start(port);

        healthCheckApp.get(rootPath + "/is-running", ctx -> ctx.result("true"));
        healthCheckApp.get(rootPath + "/version", ctx -> ctx.result(version));

        healthCheckApp.get(rootPath + "/status", ctx -> {
            JsonObject output = new JsonObject();
            isHealthy = false;
            checkBrokerStatus();
            JsonObject extractorStatuses = rocksDbExtractorClient.getStatus();
            isHealthy = isHealthy && extractorStatuses.get("isHealthy").getAsBoolean();
            checkHazelcastConnection();
            output.addProperty("brokerStatus", zeeBeBrokerConnectionStatus);
            output.add("extractorStatus", extractorStatuses);
            output.addProperty("isHazelcastAvailable", isHazelcastAvailable);
            output.addProperty("isHealthy", isHealthy);

            ctx.result(output.toString());
        });
    }

    private void checkBrokerStatus(){
        zeeBeBrokerConnectionStatus = "";
        GatewayGrpc.GatewayBlockingStub stubTowardsBroker;

        stubTowardsBroker = GatewayGrpc.newBlockingStub(ManagedChannelBuilder
                .forAddress(brokerContactPoint.split(":")[0],Integer.parseInt(brokerContactPoint.split(":")[1]))
                .usePlaintext()
                .build());

        try {
            GatewayOuterClass.TopologyResponse topology = stubTowardsBroker
                    .withDeadlineAfter(4, TimeUnit.SECONDS)
                    .topology(GatewayOuterClass.TopologyRequest.newBuilder().build());
            if(topology.getBrokersCount() > 0){
                zeeBeBrokerConnectionStatus = "Broker is available.";
                isHealthy = true;
            } else {
                zeeBeBrokerConnectionStatus = "Broker is not available.";
                isHealthy = false;
            }
        } catch (io.grpc.StatusRuntimeException ex){
            zeeBeBrokerConnectionStatus = "Broker is not available due to DEADLINE EXCEED.";
            isHealthy = false;
        } catch (Exception ex) {
            zeeBeBrokerConnectionStatus = "Broker is not available due to other error.";
            isHealthy = false;
        }

    }

    private void checkHazelcastConnection() {
        isHazelcastAvailable = HazelcastImdgClient.isHazelcastAvailable();
    }

    public void stopServer() {
        healthCheckApp.stop();
    }
}
