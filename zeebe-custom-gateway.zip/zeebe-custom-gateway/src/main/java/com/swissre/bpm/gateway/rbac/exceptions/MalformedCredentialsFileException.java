package com.swissre.bpm.gateway.rbac.exceptions;

public class MalformedCredentialsFileException extends Throwable {
    public MalformedCredentialsFileException(String message) {
        super(message);
    }
}
