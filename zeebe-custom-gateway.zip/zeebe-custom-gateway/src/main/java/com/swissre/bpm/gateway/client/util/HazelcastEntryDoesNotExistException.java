package com.swissre.bpm.gateway.client.util;

public class HazelcastEntryDoesNotExistException extends HazelcastException {

    public HazelcastEntryDoesNotExistException() {
    }

    public HazelcastEntryDoesNotExistException(String message) {
        super(message);
    }
}
