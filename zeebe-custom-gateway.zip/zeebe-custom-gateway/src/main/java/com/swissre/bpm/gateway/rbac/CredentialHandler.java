package com.swissre.bpm.gateway.rbac;

import com.swissre.bpm.gateway.rbac.exceptions.ClientAlreadyExistsException;
import com.swissre.bpm.gateway.rbac.exceptions.ClientNotFoundException;
import com.swissre.bpm.gateway.rbac.exceptions.FileManipulationException;

import java.io.IOException;

public interface CredentialHandler {

    String getPasswordHashForClient(String clientId) throws ClientNotFoundException;

    void addClientCredentials(String clientId, String passwordHash) throws IOException, FileManipulationException, ClientAlreadyExistsException;

    void removeClientCredentials(String clientId) throws IOException, FileManipulationException, ClientNotFoundException;

    void modifyClientCredentials(String clientId, String passwordHash) throws IOException, FileManipulationException, ClientNotFoundException;

}
