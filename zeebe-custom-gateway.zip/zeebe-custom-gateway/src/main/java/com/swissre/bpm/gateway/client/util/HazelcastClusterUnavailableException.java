package com.swissre.bpm.gateway.client.util;

public class HazelcastClusterUnavailableException extends HazelcastException {
    public HazelcastClusterUnavailableException() {
    }

    public HazelcastClusterUnavailableException(String message) {
        super(message);
    }
}
