package com.swissre.bpm.gateway;

import static org.junit.Assert.fail;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;

public class GatewayTest {
    private static final Logger LOG = LogManager.getLogger(GatewayTest.class);


    private static Properties appProps;

    @BeforeClass
    public static void setup(){

        try {

            appProps = new Properties();
            appProps.load(ZeebeCustomGateway.class.getClassLoader().getResourceAsStream("GatewayTest.properties"));
        } catch (IOException e) {
            LOG.error(e);
            fail("Failed to load test properties");
        }
    }

    @AfterClass
    public static void tearDown(){

    }

}
